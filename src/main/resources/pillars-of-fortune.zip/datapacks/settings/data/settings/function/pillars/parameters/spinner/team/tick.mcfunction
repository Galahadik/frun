# pillars
# spinner
# team

execute as @e[ tag = settings.pillars, tag = settings.pillars.spinner.team.button.interaction, nbt={interaction:{}}] run function settings:pillars/parameters/spinner/team/interaction/button