# EVENTS INTERACTION

function settings:gust_emitter/parameters/spinner/buy/events/buy with entity @s interaction