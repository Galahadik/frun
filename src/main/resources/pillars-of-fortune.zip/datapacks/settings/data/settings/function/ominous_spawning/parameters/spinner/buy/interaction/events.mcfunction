# EVENTS INTERACTION

function settings:ominous_spawning/parameters/spinner/buy/events/buy with entity @s interaction