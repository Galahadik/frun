# namespace: barrier

# REMOVE DATA
data modify storage data:settings t.parameters set value [{"name":"cooldown", "type":"scroller"},{"name":"narrowing", "type":"scroller"},{"name":"size", "type":"scroller"},{"name":"min_size", "type":"scroller"}]

# COORDINATES
function settings:barrier/internal/content/math/coordinates

$data modify storage data:settings t.rot set value $(rot)


# HEADER and GET Y
function settings:barrier/internal/content/math/get_y
function settings:barrier/internal/content/header with storage data:settings t

# "load_parameters": 
function settings:barrier/parameters/scroller/cooldown/load with storage data:settings t
function settings:barrier/parameters/scroller/narrowing/load with storage data:settings t
function settings:barrier/parameters/scroller/size/load with storage data:settings t
function settings:barrier/parameters/scroller/min_size/load with storage data:settings t

# FOOTER and GET Y
function settings:barrier/internal/content/math/get_y
function settings:barrier/internal/content/footer with storage data:settings t

# REMOVE DATA
data remove storage data:settings t