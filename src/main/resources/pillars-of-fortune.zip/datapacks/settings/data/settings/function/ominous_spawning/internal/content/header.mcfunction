# CONTENT

# content.components.compound: [{"text": "ᴘʟᴀʏᴇʀ ᴋɪʟʟ", "color": "white"}]
# content.components.width: "                         "

# content.appearance.header.background: -15066852
# content.appearance.compound.background: 0
# content.appearance.compound.shadow: False

# REMOVE CURRENT Y
function settings:ominous_spawning/internal/content/math/remove_y

$summon text_display ^ ^$(y_current) ^ { \
    "Tags": [ "settings.ominous_spawning" ], \
    \
    Passengers: [ \
        { \
            "comment": "=== COMPOUND ===", \
            "id": "minecraft:text_display", \
            \
            "text": [{"text": "ᴘʟᴀʏᴇʀ ᴋɪʟʟ", "color": "white"}], \
            "background": 0, \
            "shadow": False, \
            "Tags": [ settings.ominous_spawning, "settings.ominous_spawning.header.compound" ], \
            "Rotation": [$(rot)f, 0f] \
        }, \
        { \
            "id": "minecraft:text_display", \
            \
            "text": { "text": "                         " }, \
            "background": -15066852, \
            "Tags": [ settings.ominous_spawning, "settings.ominous_spawning.header.background" ], \
            "Rotation": [$(rot)f, 0f] \
        } \
    ] \
}