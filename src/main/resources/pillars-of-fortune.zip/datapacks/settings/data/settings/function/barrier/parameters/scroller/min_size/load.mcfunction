# namespace: barrier
# name: min_size
# type: scroller

# content.components.max: 250
# content.components.min: 1
# content.components.step: 1
# content.components.initial: 4

scoreboard objectives add settings.barrier.scroller.min_size dummy

scoreboard players set #max settings.barrier.scroller.min_size 250
scoreboard players set #min settings.barrier.scroller.min_size 1
scoreboard players set #step settings.barrier.scroller.min_size 1
scoreboard players set #value settings.barrier.scroller.min_size 4

# GET Y
function settings:barrier/internal/content/math/get_y

# CONTENT
function settings:barrier/parameters/scroller/min_size/content with storage data:settings t

# UPDATE
function settings:barrier/parameters/scroller/min_size/interaction/update