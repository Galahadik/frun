# "tick_parameters": 
function settings:large_smoke/parameters/spinner/buy/tick
function settings:large_smoke/parameters/spinner/equip/tick