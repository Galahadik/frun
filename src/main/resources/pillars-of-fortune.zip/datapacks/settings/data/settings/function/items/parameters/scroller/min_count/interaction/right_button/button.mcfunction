execute if score #max settings.items.scroller.min_count > #value settings.items.scroller.min_count run function settings:items/parameters/scroller/min_count/interaction/right_button/add
execute if score #max settings.items.scroller.min_count <= #value settings.items.scroller.min_count run scoreboard players operation #value settings.items.scroller.min_count = #max settings.items.scroller.min_count

function settings:items/parameters/scroller/min_count/interaction/update

data remove entity @s interaction