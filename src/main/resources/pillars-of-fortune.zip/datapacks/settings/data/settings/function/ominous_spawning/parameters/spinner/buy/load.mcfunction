# namespace: ominous_spawning
# name: buy
# type: spinner

# content.buttons_appearance: {"background":"-8403681", "shadow":"False"}
# content.buttons_content: {"text": "[купить — 520 ₿]", "color": "black"}

# content.components.initial: 0

scoreboard objectives add settings.ominous_spawning.spinner.buy dummy

scoreboard players set #value settings.ominous_spawning.spinner.buy 0

execute store result score #max settings.ominous_spawning.spinner.buy run data get entity @s data.buttons

# GET Y
function settings:ominous_spawning/internal/content/math/get_y

# CONTENT
function settings:ominous_spawning/parameters/spinner/buy/content with storage data:settings t