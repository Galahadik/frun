$execute store result score #x events.$(name) run random value $(z)..$(x)
$execute store result score #z events.$(name) run random value $(z)..$(x)
$execute store result score #y events.$(name) run random value $(y_min)..$(y_max)

# ХРАНИЛИЩА
$execute store result storage data:events t.events.lucky_chest.x int 1 run scoreboard players get #x events.$(name)
$execute store result storage data:events t.events.lucky_chest.z int 1 run scoreboard players get #z events.$(name)
$execute store result storage data:events t.events.lucky_chest.y int 1 run scoreboard players get #y events.$(name)

function events:events/type.random_player/lucky_chest/functions/spawn_chest with storage data:events t.events.lucky_chest