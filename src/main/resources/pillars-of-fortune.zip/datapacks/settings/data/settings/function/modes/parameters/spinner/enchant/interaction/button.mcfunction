scoreboard players add #value settings.modes.spinner.enchant 1
execute if score #value settings.modes.spinner.enchant >= #max settings.modes.spinner.enchant run scoreboard players set #value settings.modes.spinner.enchant 0

function settings:modes/parameters/spinner/enchant/interaction/update/update_button

function settings:modes/parameters/spinner/enchant/interaction/events

data remove entity @s interaction