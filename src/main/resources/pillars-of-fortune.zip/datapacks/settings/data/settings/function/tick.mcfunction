execute if data storage data:waiting_game { t: { state: "started" } } as @e[type=interaction, x=-21, y=112, z=10, dx=30, dy=20, dz=18] at @s run data remove entity @s interaction

# "tick_settings": 
function settings:ypmyp_link/internal/tick
function settings:start_game/internal/tick
function settings:pillars/internal/tick
function settings:modes/internal/tick
function settings:items/internal/tick
function settings:events/internal/tick
function settings:barrier/internal/tick
function settings:authors_developers/internal/tick
function settings:authors_builders/internal/tick
function settings:other/internal/tick
function settings:large_smoke/internal/tick
function settings:sculk_soul/internal/tick
function settings:trial_spawner_detection_ominous/internal/tick
function settings:glow_squid_ink/internal/tick
function settings:campfire_signal_smoke/internal/tick
function settings:totem_of_undying/internal/tick
function settings:sculk_charge/internal/tick
function settings:ominous_spawning/internal/tick
function settings:gust_emitter/internal/tick
function settings:effect_death/internal/tick
function settings:effect_kill/internal/tick
function settings:operator/internal/tick