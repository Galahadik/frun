# effect_death
kill @e[ tag = settings.effect_death ]

scoreboard players reset * settings.effect_death.spinner.unequip
scoreboard objectives remove settings.effect_death.spinner.unequip