$execute as @a run title @s title [{"text": "$(visible_name)", "color": "red"}]
execute as @a run title @s subtitle [{"text": "ивент в мире", "color": "white"}]

$scoreboard objectives add events.$(name) dummy

$execute store result score #daytime events.$(name) run time query daytime 

$execute if score #daytime events.$(name) matches 18000 run time set day

$execute if score #daytime events.$(name) matches 1000 run time set midnight

execute at @s run playsound minecraft:entity.allay.ambient_with_item master @s ~ ~ ~ 1 1