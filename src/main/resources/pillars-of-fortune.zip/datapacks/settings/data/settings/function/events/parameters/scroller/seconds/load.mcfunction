# namespace: events
# name: seconds
# type: scroller

# content.components.max: 60
# content.components.min: 0
# content.components.step: 1
# content.components.initial: 30

scoreboard objectives add settings.events.scroller.seconds dummy

scoreboard players set #max settings.events.scroller.seconds 60
scoreboard players set #min settings.events.scroller.seconds 0
scoreboard players set #step settings.events.scroller.seconds 1
scoreboard players set #value settings.events.scroller.seconds 30

# GET Y
function settings:events/internal/content/math/get_y

# CONTENT
function settings:events/parameters/scroller/seconds/content with storage data:settings t

# UPDATE
function settings:events/parameters/scroller/seconds/interaction/update