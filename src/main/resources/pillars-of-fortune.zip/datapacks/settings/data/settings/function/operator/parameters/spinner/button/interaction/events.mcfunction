# EVENTS INTERACTION

function settings:operator/parameters/spinner/button/events/start with entity @s interaction