# EVENTS INTERACTION

function settings:sculk_charge/parameters/spinner/equip/events/equip with entity @s interaction