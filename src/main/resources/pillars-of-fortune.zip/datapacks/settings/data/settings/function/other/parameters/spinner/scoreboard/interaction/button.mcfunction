scoreboard players add #value settings.other.spinner.scoreboard 1
execute if score #value settings.other.spinner.scoreboard >= #max settings.other.spinner.scoreboard run scoreboard players set #value settings.other.spinner.scoreboard 0

function settings:other/parameters/spinner/scoreboard/interaction/update/update_button

function settings:other/parameters/spinner/scoreboard/interaction/events

data remove entity @s interaction