execute as @e[  tag = settings.events, tag = settings.events.scroller.seconds.placeholder ] run data modify entity @s text set value [{"score": {"objective": "settings.events.scroller.seconds", "name": "#value"}, "color": "#ababab"}, {"text": "с", "color": "#ababab"}]

execute as @e[  tag = settings.events, tag = settings.events.scroller.seconds.buttons.left ] run data modify entity @s background set value -3727585
execute as @e[  tag = settings.events, tag = settings.events.scroller.seconds.buttons.right ] run data modify entity @s background set value -8337633

execute if score #min settings.events.scroller.seconds = #value settings.events.scroller.seconds as @e[  tag = settings.events, tag = settings.events.scroller.seconds.buttons.left ] run data modify entity @s background set value -5526613
execute if score #max settings.events.scroller.seconds = #value settings.events.scroller.seconds as @e[  tag = settings.events, tag = settings.events.scroller.seconds.buttons.right ] run data modify entity @s background set value -5526613



execute store result storage settings:pillars t.events.cooldown_seconds int 1 run scoreboard players get #value settings.events.scroller.seconds