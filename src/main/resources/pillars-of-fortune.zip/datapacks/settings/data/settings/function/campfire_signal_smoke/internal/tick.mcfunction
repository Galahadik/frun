# "tick_parameters": 
function settings:campfire_signal_smoke/parameters/spinner/buy/tick
function settings:campfire_signal_smoke/parameters/spinner/equip/tick