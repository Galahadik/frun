# CONTENT

# content.components.compound: [{"text": "ʏᴘ—ᴍʏᴘ ꜱᴛᴜᴅɪᴏ", "color": "white"}]
# content.components.width: "                         "

# content.appearance.header.background: -13420999
# content.appearance.compound.background: 0
# content.appearance.compound.shadow: False

# REMOVE CURRENT Y
function settings:ypmyp_link/internal/content/math/remove_y

$summon text_display ^ ^$(y_current) ^ { \
    "Tags": [ "settings.ypmyp_link" ], \
    \
    Passengers: [ \
        { \
            "comment": "=== COMPOUND ===", \
            "id": "minecraft:text_display", \
            \
            "text": [{"text": "ʏᴘ—ᴍʏᴘ ꜱᴛᴜᴅɪᴏ", "color": "white"}], \
            "background": 0, \
            "shadow": False, \
            "Tags": [ settings.ypmyp_link, "settings.ypmyp_link.header.compound" ], \
            "Rotation": [$(rot)f, 0f] \
        }, \
        { \
            "id": "minecraft:text_display", \
            \
            "text": { "text": "                         " }, \
            "background": -13420999, \
            "Tags": [ settings.ypmyp_link, "settings.ypmyp_link.header.background" ], \
            "Rotation": [$(rot)f, 0f] \
        } \
    ] \
}