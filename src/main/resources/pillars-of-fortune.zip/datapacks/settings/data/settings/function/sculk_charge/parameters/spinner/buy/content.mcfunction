# namespace: sculk_charge
# name: buy
# type: spinner

# content.appearance.content.background: -15066852

# content.appearance.compound.background: 0
# content.appearance.compound.shadow: False

# content.components.compound: [{"text": "скалк заряды", "color": "white"}]
# content.components.initial: 0

# content.components.content.width:                          

# REMOVE CURRENT Y
function settings:sculk_charge/internal/content/math/remove_y

$summon text_display ^ ^$(y_current) ^ { \
    "Tags": [ "settings.sculk_charge" ], \
    \
    Passengers: [ \
        { \
            "comment": "=== COMPOUND ===", \
            "id": "minecraft:text_display", \
            \
            "text": [{"text": "скалк заряды", "color": "white"}], \
            "background": 0, \
            "shadow": False, \
            "Tags": [ "settings.sculk_charge", "settings.sculk_charge.spinner.buy.compound" ], \
            "transformation": { \
                "translation": [0, 0.4, 0.01], \
                "scale": [1, 1, 1], \
                "left_rotation": [0, 0, 0, 1], \
                "right_rotation": [0, 0, 0, 1] \
            }, \
            "Rotation": [$(rot)f, 0f] \
        }, \
        { \
            "comment": "=== BUTTON ===", \
            "id": "minecraft:text_display", \
            \
            "text": {"text": ""}, \
            "background": 0, \
            "shadow": false, \
            "Tags": [ "settings.sculk_charge", "settings.sculk_charge.spinner.buy.button" ], \
            "transformation": { \
                "translation": [0, 0.1, 0.01], \
                "scale": [1, 1, 1], \
                "left_rotation": [0, 0, 0, 1], \
                "right_rotation": [0, 0, 0, 1] \
            }, \
            "data": { \
                "buttons": [{"text": "[купить — 379 ₿]", "color": "black"}], \
                "appearance": [{"background":"-8403681", "shadow":"False"}], \
                "current_id": 0, \
                "current_button": {}, \
                "current_appearance": {} \
            }, \
            "Rotation": [$(rot)f, 0f] \
        }, \
        { \
            "comment": "=== BACKGROUND ===", \
            "id": "minecraft:text_display", \
            \
            "text": { "text": "                         " }, \
            "background": -15066852, \
            "Tags": [ "settings.sculk_charge", "settings.sculk_charge.spinner.buy.background" ], \
            "transformation": { \
                "translation": [0, 0, 0], \
                "scale": [1, 3, 1], \
                "left_rotation": [0, 0, 0, 1], \
                "right_rotation": [0, 0, 0, 1] \
            }, \
            "Rotation": [$(rot)f, 0f] \
        } \
    ] \
}

$summon interaction ^ ^$(y_current) ^ { \
    "Tags": [ "settings.sculk_charge", "settings.sculk_charge.spinner.buy.button.interaction" ], \
    "width": 1f, \
    "height": 0.25f \
}
execute as @e[ tag = settings.sculk_charge, tag = settings.sculk_charge.spinner.buy.button.interaction] at @s run tp @s ^ ^0.1 ^

function settings:sculk_charge/parameters/spinner/buy/interaction/update/update_button