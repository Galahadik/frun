# large_smoke
kill @e[ tag = settings.large_smoke ]

scoreboard players reset * settings.large_smoke.spinner.buy
scoreboard objectives remove settings.large_smoke.spinner.buy
scoreboard players reset * settings.large_smoke.spinner.equip
scoreboard objectives remove settings.large_smoke.spinner.equip