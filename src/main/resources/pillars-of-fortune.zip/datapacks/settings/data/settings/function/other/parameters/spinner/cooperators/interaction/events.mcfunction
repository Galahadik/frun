# EVENTS INTERACTION

function settings:other/parameters/spinner/cooperators/events/button with entity @s interaction