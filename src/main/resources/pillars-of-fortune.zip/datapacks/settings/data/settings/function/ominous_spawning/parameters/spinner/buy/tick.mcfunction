# ominous_spawning
# spinner
# buy

execute as @e[ tag = settings.ominous_spawning, tag = settings.ominous_spawning.spinner.buy.button.interaction, nbt={interaction:{}}] run function settings:ominous_spawning/parameters/spinner/buy/interaction/button