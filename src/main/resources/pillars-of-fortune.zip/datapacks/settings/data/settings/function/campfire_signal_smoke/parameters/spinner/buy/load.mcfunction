# namespace: campfire_signal_smoke
# name: buy
# type: spinner

# content.buttons_appearance: {"background":"-8403681", "shadow":"False"}
# content.buttons_content: {"text": "[купить — 389 ₿]", "color": "black"}

# content.components.initial: 0

scoreboard objectives add settings.campfire_signal_smoke.spinner.buy dummy

scoreboard players set #value settings.campfire_signal_smoke.spinner.buy 0

execute store result score #max settings.campfire_signal_smoke.spinner.buy run data get entity @s data.buttons

# GET Y
function settings:campfire_signal_smoke/internal/content/math/get_y

# CONTENT
function settings:campfire_signal_smoke/parameters/spinner/buy/content with storage data:settings t