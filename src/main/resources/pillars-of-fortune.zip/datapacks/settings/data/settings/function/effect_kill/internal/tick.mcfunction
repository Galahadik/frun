# "tick_parameters": 
function settings:effect_kill/parameters/spinner/unequip/tick