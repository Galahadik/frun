# namespace: sculk_charge

# REMOVE DATA
data modify storage data:settings t.parameters set value [{"name":"buy", "type":"spinner"},{"name":"equip", "type":"spinner"}]

# COORDINATES
function settings:sculk_charge/internal/content/math/coordinates

$data modify storage data:settings t.rot set value $(rot)


# HEADER and GET Y
function settings:sculk_charge/internal/content/math/get_y
function settings:sculk_charge/internal/content/header with storage data:settings t

# "load_parameters": 
function settings:sculk_charge/parameters/spinner/buy/load with storage data:settings t
function settings:sculk_charge/parameters/spinner/equip/load with storage data:settings t

# FOOTER and GET Y
function settings:sculk_charge/internal/content/math/get_y
function settings:sculk_charge/internal/content/footer with storage data:settings t

# REMOVE DATA
data remove storage data:settings t