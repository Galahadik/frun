# "tick_parameters": 
function settings:sculk_charge/parameters/spinner/buy/tick
function settings:sculk_charge/parameters/spinner/equip/tick