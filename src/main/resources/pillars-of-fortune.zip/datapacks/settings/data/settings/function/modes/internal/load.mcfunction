# namespace: modes

# REMOVE DATA
data modify storage data:settings t.parameters set value [{"name":"events", "type":"spinner"},{"name":"enchant", "type":"spinner"},{"name":"slime", "type":"spinner"}]

# COORDINATES
function settings:modes/internal/content/math/coordinates

$data modify storage data:settings t.rot set value $(rot)


# HEADER and GET Y
function settings:modes/internal/content/math/get_y
function settings:modes/internal/content/header with storage data:settings t

# "load_parameters": 
function settings:modes/parameters/spinner/events/load with storage data:settings t
function settings:modes/parameters/spinner/enchant/load with storage data:settings t
function settings:modes/parameters/spinner/slime/load with storage data:settings t

# FOOTER and GET Y
function settings:modes/internal/content/math/get_y
function settings:modes/internal/content/footer with storage data:settings t

# REMOVE DATA
data remove storage data:settings t