data modify storage data:settings temp set value {}
data modify storage data:settings temp.temp_data set value {}

# VARIABLES
data modify storage data:settings temp.variables.multiplier_y set value 0.75
data modify storage data:settings temp.variables.current_y set value 0

# DATA
data modify storage data:settings temp.data.options set value [{"type":"text", "id":"header", "data": {"customize":{"background":0},"components":{"line_1":[{"text":"Hello, World!"}],"line_2":[{"text":"Hi"}]}}}]