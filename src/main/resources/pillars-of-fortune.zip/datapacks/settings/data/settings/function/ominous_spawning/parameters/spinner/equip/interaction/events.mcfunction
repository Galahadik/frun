# EVENTS INTERACTION

function settings:ominous_spawning/parameters/spinner/equip/events/equip with entity @s interaction