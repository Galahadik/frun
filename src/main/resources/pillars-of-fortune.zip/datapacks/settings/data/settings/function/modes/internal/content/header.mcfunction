# CONTENT

# content.components.compound: [{"text": "ᴍᴏᴅᴇꜱ", "color": "white"}]
# content.components.width: "                         "

# content.appearance.header.background: -15066852
# content.appearance.compound.background: 0
# content.appearance.compound.shadow: False

# REMOVE CURRENT Y
function settings:modes/internal/content/math/remove_y

$summon text_display ^ ^$(y_current) ^ { \
    "Tags": [ "settings.modes" ], \
    \
    Passengers: [ \
        { \
            "comment": "=== COMPOUND ===", \
            "id": "minecraft:text_display", \
            \
            "text": [{"text": "ᴍᴏᴅᴇꜱ", "color": "white"}], \
            "background": 0, \
            "shadow": False, \
            "Tags": [ settings.modes, "settings.modes.header.compound" ], \
            "Rotation": [$(rot)f, 0f] \
        }, \
        { \
            "id": "minecraft:text_display", \
            \
            "text": { "text": "                         " }, \
            "background": -15066852, \
            "Tags": [ settings.modes, "settings.modes.header.background" ], \
            "Rotation": [$(rot)f, 0f] \
        } \
    ] \
}