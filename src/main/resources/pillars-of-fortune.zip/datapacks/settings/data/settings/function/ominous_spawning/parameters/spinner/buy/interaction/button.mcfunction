scoreboard players add #value settings.ominous_spawning.spinner.buy 1
execute if score #value settings.ominous_spawning.spinner.buy >= #max settings.ominous_spawning.spinner.buy run scoreboard players set #value settings.ominous_spawning.spinner.buy 0

function settings:ominous_spawning/parameters/spinner/buy/interaction/update/update_button

function settings:ominous_spawning/parameters/spinner/buy/interaction/events

data remove entity @s interaction