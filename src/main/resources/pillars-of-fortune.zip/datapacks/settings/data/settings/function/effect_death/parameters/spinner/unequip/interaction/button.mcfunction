scoreboard players add #value settings.effect_death.spinner.unequip 1
execute if score #value settings.effect_death.spinner.unequip >= #max settings.effect_death.spinner.unequip run scoreboard players set #value settings.effect_death.spinner.unequip 0

function settings:effect_death/parameters/spinner/unequip/interaction/update/update_button

function settings:effect_death/parameters/spinner/unequip/interaction/events

data remove entity @s interaction