scoreboard players add #value settings.sculk_charge.spinner.buy 1
execute if score #value settings.sculk_charge.spinner.buy >= #max settings.sculk_charge.spinner.buy run scoreboard players set #value settings.sculk_charge.spinner.buy 0

function settings:sculk_charge/parameters/spinner/buy/interaction/update/update_button

function settings:sculk_charge/parameters/spinner/buy/interaction/events

data remove entity @s interaction