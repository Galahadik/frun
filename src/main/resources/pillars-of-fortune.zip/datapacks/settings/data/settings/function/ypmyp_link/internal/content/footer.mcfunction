# CONTENT

# content.components.content.width: "                         "

# content.appearance.footer.background: -13420999

# FOOTER
$summon text_display ~ ~$(y_current) ~ { \
    "text": { "text": "                         " }, \
    "background": -13420999, \
    "Tags": [ settings.ypmyp_link, "settings.ypmyp_link.footer.background" ], \
    "Rotation": [$(rot)f, 0f] \
}