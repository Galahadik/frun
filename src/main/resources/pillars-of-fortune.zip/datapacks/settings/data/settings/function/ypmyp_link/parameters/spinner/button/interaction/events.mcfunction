# EVENTS INTERACTION

function settings:ypmyp_link/parameters/spinner/button/events/button with entity @s interaction