# namespace: barrier
# name: narrowing
# type: scroller

# content.components.max: 999
# content.components.min: 0
# content.components.step: 1
# content.components.initial: 2

scoreboard objectives add settings.barrier.scroller.narrowing dummy

scoreboard players set #max settings.barrier.scroller.narrowing 999
scoreboard players set #min settings.barrier.scroller.narrowing 0
scoreboard players set #step settings.barrier.scroller.narrowing 1
scoreboard players set #value settings.barrier.scroller.narrowing 2

# GET Y
function settings:barrier/internal/content/math/get_y

# CONTENT
function settings:barrier/parameters/scroller/narrowing/content with storage data:settings t

# UPDATE
function settings:barrier/parameters/scroller/narrowing/interaction/update