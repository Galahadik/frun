execute store result entity @s data.current_id int 1 run scoreboard players get #value settings.other.spinner.scoreboard

function settings:other/parameters/spinner/scoreboard/interaction/update/set_button with entity @s data

execute store result score #max settings.other.spinner.scoreboard run data get entity @s data.buttons