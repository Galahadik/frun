# operator
kill @e[ tag = settings.operator ]

scoreboard players reset * settings.operator.spinner.button
scoreboard objectives remove settings.operator.spinner.button