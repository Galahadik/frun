# modes
kill @e[ tag = settings.modes ]

scoreboard players reset * settings.modes.spinner.events
scoreboard objectives remove settings.modes.spinner.events
scoreboard players reset * settings.modes.spinner.enchant
scoreboard objectives remove settings.modes.spinner.enchant
scoreboard players reset * settings.modes.spinner.slime
scoreboard objectives remove settings.modes.spinner.slime