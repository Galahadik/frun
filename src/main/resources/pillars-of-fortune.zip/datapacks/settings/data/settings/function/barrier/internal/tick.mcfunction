# "tick_parameters": 
function settings:barrier/parameters/scroller/cooldown/tick
function settings:barrier/parameters/scroller/narrowing/tick
function settings:barrier/parameters/scroller/size/tick
function settings:barrier/parameters/scroller/min_size/tick