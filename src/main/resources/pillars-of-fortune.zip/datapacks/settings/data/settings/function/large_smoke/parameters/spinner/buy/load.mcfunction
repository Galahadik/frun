# namespace: large_smoke
# name: buy
# type: spinner

# content.buttons_appearance: {"background":"-8403681", "shadow":"False"}
# content.buttons_content: {"text": "[купить — 290 ₿]", "color": "black"}

# content.components.initial: 0

scoreboard objectives add settings.large_smoke.spinner.buy dummy

scoreboard players set #value settings.large_smoke.spinner.buy 0

execute store result score #max settings.large_smoke.spinner.buy run data get entity @s data.buttons

# GET Y
function settings:large_smoke/internal/content/math/get_y

# CONTENT
function settings:large_smoke/parameters/spinner/buy/content with storage data:settings t