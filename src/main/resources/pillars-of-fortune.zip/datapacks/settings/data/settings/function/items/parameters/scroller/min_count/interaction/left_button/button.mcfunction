execute if score #min settings.items.scroller.min_count < #value settings.items.scroller.min_count run function settings:items/parameters/scroller/min_count/interaction/left_button/remove
execute if score #min settings.items.scroller.min_count >= #value settings.items.scroller.min_count run scoreboard players operation #value settings.items.scroller.min_count = #min settings.items.scroller.min_count

function settings:items/parameters/scroller/min_count/interaction/update

data remove entity @s interaction