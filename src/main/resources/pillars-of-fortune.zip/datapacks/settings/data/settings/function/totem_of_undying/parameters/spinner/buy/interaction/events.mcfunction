# EVENTS INTERACTION

function settings:totem_of_undying/parameters/spinner/buy/events/buy with entity @s interaction