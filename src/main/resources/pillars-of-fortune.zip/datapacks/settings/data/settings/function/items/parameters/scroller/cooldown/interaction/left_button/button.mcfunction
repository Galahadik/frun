execute if score #min settings.items.scroller.cooldown < #value settings.items.scroller.cooldown run function settings:items/parameters/scroller/cooldown/interaction/left_button/remove
execute if score #min settings.items.scroller.cooldown >= #value settings.items.scroller.cooldown run scoreboard players operation #value settings.items.scroller.cooldown = #min settings.items.scroller.cooldown

function settings:items/parameters/scroller/cooldown/interaction/update

data remove entity @s interaction