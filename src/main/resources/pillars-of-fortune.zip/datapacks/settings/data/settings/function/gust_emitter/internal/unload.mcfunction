# gust_emitter
kill @e[ tag = settings.gust_emitter ]

scoreboard players reset * settings.gust_emitter.spinner.buy
scoreboard objectives remove settings.gust_emitter.spinner.buy
scoreboard players reset * settings.gust_emitter.spinner.equip
scoreboard objectives remove settings.gust_emitter.spinner.equip