$summon text_display ^ ^$(y_current) ^ { \
    "Tags": [ "settings.authors_builders" ], \
    \
    Passengers: [ \
        { \
            "comment": "=== TEXT 1 ===", \
            "id": "minecraft:text_display", \
            \
            "text": [{"text": "LolGrechek", "color": "gray"}], \
            "background": 0, \
            "shadow": False, \
            "Tags": [ "settings.authors_builders", "settings.authors_builders.text.line_1.text1" ], \
            "transformation": { \
                "translation": [0, 0.4, 0.01], \
                "scale": [1, 1, 1], \
                "left_rotation": [0, 0, 0, 1], \
                "right_rotation": [0, 0, 0, 1] \
            }, \
            "Rotation": [$(rot)f, 0f] \
        }, \
        { \
            "comment": "=== TEXT 2 ===", \
            "id": "minecraft:text_display", \
            \
            "text": [{"text": "Waspockx", "color": "gray"}], \
            "background": 0, \
            "shadow": False, \
            "Tags": [ "settings.authors_builders", "settings.authors_builders.text.line_1.text2" ], \
            "transformation": { \
                "translation": [0, 0.1, 0.01], \
                "scale": [1, 1, 1], \
                "left_rotation": [0, 0, 0, 1], \
                "right_rotation": [0, 0, 0, 1] \
            }, \
            "Rotation": [$(rot)f, 0f] \
        }, \
        { \
            "comment": "=== BACKGROUND ===", \
            "id": "minecraft:text_display", \
            \
            "text": { "text": "                         " }, \
            "background": -12103854, \
            "Tags": [ "settings.authors_builders", "settings.authors_builders.text.line_1.background" ], \
            "transformation": { \
                "translation": [0, 0, 0], \
                "scale": [1, 3, 1], \
                "left_rotation": [0, 0, 0, 1], \
                "right_rotation": [0, 0, 0, 1] \
            }, \
            "Rotation": [$(rot)f, 0f] \
        } \
    ] \
}