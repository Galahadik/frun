# items
# scroller
# cooldown

execute as @e[ tag = settings.items, tag = settings.items.scroller.cooldown.buttons.left.interaction, nbt={interaction:{}}] run function settings:items/parameters/scroller/cooldown/interaction/left_button/button

execute as @e[ tag = settings.items, tag = settings.items.scroller.cooldown.buttons.right.interaction, nbt={interaction:{}}] run function settings:items/parameters/scroller/cooldown/interaction/right_button/button