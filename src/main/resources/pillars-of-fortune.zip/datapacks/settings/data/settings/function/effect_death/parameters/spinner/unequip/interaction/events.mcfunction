# EVENTS INTERACTION

function settings:effect_death/parameters/spinner/unequip/events/unequip with entity @s interaction