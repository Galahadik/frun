# barrier
# scroller
# min_size

execute as @e[ tag = settings.barrier, tag = settings.barrier.scroller.min_size.buttons.left.interaction, nbt={interaction:{}}] run function settings:barrier/parameters/scroller/min_size/interaction/left_button/button

execute as @e[ tag = settings.barrier, tag = settings.barrier.scroller.min_size.buttons.right.interaction, nbt={interaction:{}}] run function settings:barrier/parameters/scroller/min_size/interaction/right_button/button