$data modify storage data:settings temp.current_y set value $(current_index)
$execute store result storage data:settings temp.current_y float $(multiplier) run data get storage data:settings temp.current_y

# WORKING IN PROGRESS