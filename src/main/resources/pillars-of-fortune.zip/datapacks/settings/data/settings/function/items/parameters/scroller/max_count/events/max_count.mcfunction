execute if score #value settings.items.scroller.min_count > #value settings.items.scroller.max_count run scoreboard players operation #value settings.items.scroller.min_count = #value settings.items.scroller.max_count

function settings:items/parameters/scroller/min_count/interaction/update