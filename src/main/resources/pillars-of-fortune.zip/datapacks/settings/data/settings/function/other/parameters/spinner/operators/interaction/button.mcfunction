$execute unless entity @a[ nbt={ UUID: $(player) } , tag = player.operator ] run function settings:other/parameters/spinner/operators/interaction/check_player with entity @s interaction
$execute unless entity @a[ nbt={ UUID: $(player) } , tag = player.operator ] run return fail

scoreboard players add #value settings.other.spinner.operators 1
execute if score #value settings.other.spinner.operators >= #max settings.other.spinner.operators run scoreboard players set #value settings.other.spinner.operators 0

function settings:other/parameters/spinner/operators/interaction/update/update_button

function settings:other/parameters/spinner/operators/interaction/events

data remove entity @s interaction