# operator
# spinner
# button

execute as @e[ tag = settings.operator, tag = settings.operator.spinner.button.button.interaction, nbt={interaction:{}}] run function settings:operator/parameters/spinner/button/interaction/button