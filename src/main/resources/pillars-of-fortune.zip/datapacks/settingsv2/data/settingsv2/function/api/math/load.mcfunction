#execute store result storage data:settings temp.current_index int 1 run scoreboard players get #current_index data.settings 1
#function settingsv2:math/get_y with storage data:settings temp

# WORKING IN PROGRESS