scoreboard players add #value settings.totem_of_undying.spinner.equip 1
execute if score #value settings.totem_of_undying.spinner.equip >= #max settings.totem_of_undying.spinner.equip run scoreboard players set #value settings.totem_of_undying.spinner.equip 0

function settings:totem_of_undying/parameters/spinner/equip/interaction/update/update_button

function settings:totem_of_undying/parameters/spinner/equip/interaction/events

data remove entity @s interaction