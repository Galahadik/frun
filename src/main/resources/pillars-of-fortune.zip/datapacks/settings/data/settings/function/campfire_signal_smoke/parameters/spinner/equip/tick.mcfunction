# campfire_signal_smoke
# spinner
# equip

execute as @e[ tag = settings.campfire_signal_smoke, tag = settings.campfire_signal_smoke.spinner.equip.button.interaction, nbt={interaction:{}}] run function settings:campfire_signal_smoke/parameters/spinner/equip/interaction/button