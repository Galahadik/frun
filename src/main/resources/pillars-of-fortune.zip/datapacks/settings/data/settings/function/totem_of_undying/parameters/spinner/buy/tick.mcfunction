# totem_of_undying
# spinner
# buy

execute as @e[ tag = settings.totem_of_undying, tag = settings.totem_of_undying.spinner.buy.button.interaction, nbt={interaction:{}}] run function settings:totem_of_undying/parameters/spinner/buy/interaction/button