# namespace: effect_death
# name: unequip
# type: spinner

# content.buttons_appearance: {"background":"-273091", "shadow":"False"}
# content.buttons_content: {"text": "[снять]", "color": "black"}

# content.components.initial: 0

scoreboard objectives add settings.effect_death.spinner.unequip dummy

scoreboard players set #value settings.effect_death.spinner.unequip 0

execute store result score #max settings.effect_death.spinner.unequip run data get entity @s data.buttons

# GET Y
function settings:effect_death/internal/content/math/get_y

# CONTENT
function settings:effect_death/parameters/spinner/unequip/content with storage data:settings t