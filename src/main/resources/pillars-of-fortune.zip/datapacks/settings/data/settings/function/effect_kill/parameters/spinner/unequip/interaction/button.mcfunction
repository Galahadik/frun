scoreboard players add #value settings.effect_kill.spinner.unequip 1
execute if score #value settings.effect_kill.spinner.unequip >= #max settings.effect_kill.spinner.unequip run scoreboard players set #value settings.effect_kill.spinner.unequip 0

function settings:effect_kill/parameters/spinner/unequip/interaction/update/update_button

function settings:effect_kill/parameters/spinner/unequip/interaction/events

data remove entity @s interaction