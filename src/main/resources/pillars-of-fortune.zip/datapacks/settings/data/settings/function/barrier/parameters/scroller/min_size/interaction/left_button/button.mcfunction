execute if score #min settings.barrier.scroller.min_size < #value settings.barrier.scroller.min_size run function settings:barrier/parameters/scroller/min_size/interaction/left_button/remove
execute if score #min settings.barrier.scroller.min_size >= #value settings.barrier.scroller.min_size run scoreboard players operation #value settings.barrier.scroller.min_size = #min settings.barrier.scroller.min_size

function settings:barrier/parameters/scroller/min_size/interaction/update

data remove entity @s interaction