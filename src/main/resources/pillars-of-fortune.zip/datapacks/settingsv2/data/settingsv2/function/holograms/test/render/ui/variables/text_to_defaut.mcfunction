# COMPONENTS
execute unless data storage data:settings temp.temp_data.option.data.components.line_1 run data modify storage data:settings temp.temp_data.option.data.components.line_1 set value []
execute unless data storage data:settings temp.temp_data.option.data.components.line_2 run data modify storage data:settings temp.temp_data.option.data.components.line_2 set value []

# APPEARANCE
execute unless data storage data:settings temp.temp_data.option.data.appearance.background run data modify storage data:settings temp.temp_data.option.data.appearance.background set value 0