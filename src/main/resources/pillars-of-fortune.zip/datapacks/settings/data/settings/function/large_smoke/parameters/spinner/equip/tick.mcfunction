# large_smoke
# spinner
# equip

execute as @e[ tag = settings.large_smoke, tag = settings.large_smoke.spinner.equip.button.interaction, nbt={interaction:{}}] run function settings:large_smoke/parameters/spinner/equip/interaction/button