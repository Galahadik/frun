$execute as @a run title @s title [{"text": "$(visible_name)", "color": "red"}]
execute as @a run title @s subtitle [{"text": "ивент в мире", "color": "white"}]

execute positioned -5 1932 250 run summon phantom ~ ~ ~