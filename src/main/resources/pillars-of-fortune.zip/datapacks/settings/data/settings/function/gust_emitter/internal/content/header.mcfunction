# CONTENT

# content.components.compound: [{"text": "ᴘʟᴀʏᴇʀ ᴋɪʟʟ", "color": "white"}]
# content.components.width: "                         "

# content.appearance.header.background: -15066852
# content.appearance.compound.background: 0
# content.appearance.compound.shadow: False

# REMOVE CURRENT Y
function settings:gust_emitter/internal/content/math/remove_y

$summon text_display ^ ^$(y_current) ^ { \
    "Tags": [ "settings.gust_emitter" ], \
    \
    Passengers: [ \
        { \
            "comment": "=== COMPOUND ===", \
            "id": "minecraft:text_display", \
            \
            "text": [{"text": "ᴘʟᴀʏᴇʀ ᴋɪʟʟ", "color": "white"}], \
            "background": 0, \
            "shadow": False, \
            "Tags": [ settings.gust_emitter, "settings.gust_emitter.header.compound" ], \
            "Rotation": [$(rot)f, 0f] \
        }, \
        { \
            "id": "minecraft:text_display", \
            \
            "text": { "text": "                         " }, \
            "background": -15066852, \
            "Tags": [ settings.gust_emitter, "settings.gust_emitter.header.background" ], \
            "Rotation": [$(rot)f, 0f] \
        } \
    ] \
}