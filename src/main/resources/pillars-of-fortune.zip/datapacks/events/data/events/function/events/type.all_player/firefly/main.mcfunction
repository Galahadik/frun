$title @s title [{"text": "$(visible_name)", "color": "red"}]
title @s subtitle [{"text": "ивент над всеми игроками", "color": "white"}]

effect give @s glowing 24 1 true
execute at @s run particle minecraft:firefly ~ ~1 ~ 1 1 1 1 50