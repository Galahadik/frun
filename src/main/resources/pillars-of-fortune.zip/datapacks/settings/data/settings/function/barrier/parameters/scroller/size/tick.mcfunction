# barrier
# scroller
# size

execute as @e[ tag = settings.barrier, tag = settings.barrier.scroller.size.buttons.left.interaction, nbt={interaction:{}}] run function settings:barrier/parameters/scroller/size/interaction/left_button/button

execute as @e[ tag = settings.barrier, tag = settings.barrier.scroller.size.buttons.right.interaction, nbt={interaction:{}}] run function settings:barrier/parameters/scroller/size/interaction/right_button/button