# CONTENT

# content.components.compound: [{"text": "ɢᴀᴍᴇ", "color": "white"}]
# content.components.width: "                         "

# content.appearance.header.background: -15066852
# content.appearance.compound.background: 0
# content.appearance.compound.shadow: False

# REMOVE CURRENT Y
function settings:operator/internal/content/math/remove_y

$summon text_display ^ ^$(y_current) ^ { \
    "Tags": [ "settings.operator" ], \
    \
    Passengers: [ \
        { \
            "comment": "=== COMPOUND ===", \
            "id": "minecraft:text_display", \
            \
            "text": [{"text": "ᴏᴘᴇʀᴀᴛᴏʀ", "color": "white"}], \
            "background": 0, \
            "shadow": False, \
            "Tags": [ settings.operator, "settings.operator.header.compound" ], \
            "Rotation": [$(rot)f, 0f] \
        }, \
        { \
            "id": "minecraft:text_display", \
            \
            "text": { "text": "                         " }, \
            "background": -15066852, \
            "Tags": [ settings.operator, "settings.operator.header.background" ], \
            "Rotation": [$(rot)f, 0f] \
        } \
    ] \
}