# EVENTS INTERACTION

function settings:campfire_signal_smoke/parameters/spinner/equip/events/equip with entity @s interaction