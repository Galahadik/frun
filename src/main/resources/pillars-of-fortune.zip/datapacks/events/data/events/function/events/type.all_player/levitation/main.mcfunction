$title @s title [{"text": "$(visible_name)", "color": "red"}]
title @s subtitle [{"text": "ивент над всеми игроками", "color": "white"}]

effect give @s minecraft:levitation 2 1 true