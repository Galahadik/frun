execute store result entity @s data.current_id int 1 run scoreboard players get #value settings.campfire_signal_smoke.spinner.equip

function settings:campfire_signal_smoke/parameters/spinner/equip/interaction/update/set_button with entity @s data

execute store result score #max settings.campfire_signal_smoke.spinner.equip run data get entity @s data.buttons