# ominous_spawning
# spinner
# equip

execute as @e[ tag = settings.ominous_spawning, tag = settings.ominous_spawning.spinner.equip.button.interaction, nbt={interaction:{}}] run function settings:ominous_spawning/parameters/spinner/equip/interaction/button