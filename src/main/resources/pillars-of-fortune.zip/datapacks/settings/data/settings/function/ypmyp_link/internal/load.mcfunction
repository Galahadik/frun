# namespace: ypmyp_link

# REMOVE DATA
data modify storage data:settings t.parameters set value [{"name":"button", "type":"spinner"}]

# COORDINATES
function settings:ypmyp_link/internal/content/math/coordinates

$data modify storage data:settings t.rot set value $(rot)


# HEADER and GET Y
function settings:ypmyp_link/internal/content/math/get_y
function settings:ypmyp_link/internal/content/header with storage data:settings t

# "load_parameters": 
function settings:ypmyp_link/parameters/spinner/button/load with storage data:settings t

# FOOTER and GET Y
function settings:ypmyp_link/internal/content/math/get_y
function settings:ypmyp_link/internal/content/footer with storage data:settings t

# REMOVE DATA
data remove storage data:settings t