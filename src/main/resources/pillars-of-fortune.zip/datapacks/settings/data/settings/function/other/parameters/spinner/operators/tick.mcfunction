# other
# spinner
# operators

execute as @e[ tag = settings.other, tag = settings.other.spinner.operators.button.interaction, nbt={interaction:{}}] run function settings:other/parameters/spinner/operators/interaction/button with entity @s interaction