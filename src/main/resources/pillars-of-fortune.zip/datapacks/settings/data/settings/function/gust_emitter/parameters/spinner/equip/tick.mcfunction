# gust_emitter
# spinner
# equip

execute as @e[ tag = settings.gust_emitter, tag = settings.gust_emitter.spinner.equip.button.interaction, nbt={interaction:{}}] run function settings:gust_emitter/parameters/spinner/equip/interaction/button