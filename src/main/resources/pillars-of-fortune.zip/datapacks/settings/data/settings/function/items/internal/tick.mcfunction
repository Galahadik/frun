# "tick_parameters": 
function settings:items/parameters/scroller/cooldown/tick
function settings:items/parameters/scroller/min_count/tick
function settings:items/parameters/scroller/max_count/tick