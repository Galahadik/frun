# "tick_parameters": 
function settings:effect_death/parameters/spinner/unequip/tick