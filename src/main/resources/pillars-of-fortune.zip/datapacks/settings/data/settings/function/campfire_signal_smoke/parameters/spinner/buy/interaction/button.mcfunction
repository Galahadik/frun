scoreboard players add #value settings.campfire_signal_smoke.spinner.buy 1
execute if score #value settings.campfire_signal_smoke.spinner.buy >= #max settings.campfire_signal_smoke.spinner.buy run scoreboard players set #value settings.campfire_signal_smoke.spinner.buy 0

function settings:campfire_signal_smoke/parameters/spinner/buy/interaction/update/update_button

function settings:campfire_signal_smoke/parameters/spinner/buy/interaction/events

data remove entity @s interaction