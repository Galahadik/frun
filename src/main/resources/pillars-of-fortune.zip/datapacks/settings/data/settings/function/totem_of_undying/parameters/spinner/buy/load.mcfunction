# namespace: totem_of_undying
# name: buy
# type: spinner

# content.buttons_appearance: {"background":"-8403681", "shadow":"False"}
# content.buttons_content: {"text": "[купить — 480 ₿]", "color": "black"}

# content.components.initial: 0

scoreboard objectives add settings.totem_of_undying.spinner.buy dummy

scoreboard players set #value settings.totem_of_undying.spinner.buy 0

execute store result score #max settings.totem_of_undying.spinner.buy run data get entity @s data.buttons

# GET Y
function settings:totem_of_undying/internal/content/math/get_y

# CONTENT
function settings:totem_of_undying/parameters/spinner/buy/content with storage data:settings t