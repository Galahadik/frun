scoreboard players add #value settings.modes.spinner.slime 1
execute if score #value settings.modes.spinner.slime >= #max settings.modes.spinner.slime run scoreboard players set #value settings.modes.spinner.slime 0

function settings:modes/parameters/spinner/slime/interaction/update/update_button

function settings:modes/parameters/spinner/slime/interaction/events

data remove entity @s interaction