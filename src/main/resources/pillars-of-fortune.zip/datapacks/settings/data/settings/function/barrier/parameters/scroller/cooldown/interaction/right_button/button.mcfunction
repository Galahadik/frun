execute if score #max settings.barrier.scroller.cooldown > #value settings.barrier.scroller.cooldown run function settings:barrier/parameters/scroller/cooldown/interaction/right_button/add
execute if score #max settings.barrier.scroller.cooldown <= #value settings.barrier.scroller.cooldown run scoreboard players operation #value settings.barrier.scroller.cooldown = #max settings.barrier.scroller.cooldown

function settings:barrier/parameters/scroller/cooldown/interaction/update

data remove entity @s interaction