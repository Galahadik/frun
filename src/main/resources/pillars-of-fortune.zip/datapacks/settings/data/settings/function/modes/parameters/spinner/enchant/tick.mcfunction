# modes
# spinner
# enchant

execute as @e[ tag = settings.modes, tag = settings.modes.spinner.enchant.button.interaction, nbt={interaction:{}}] run function settings:modes/parameters/spinner/enchant/interaction/button