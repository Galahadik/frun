# barrier
kill @e[ tag = settings.barrier ]

scoreboard players reset * settings.barrier.scroller.cooldown
scoreboard objectives remove settings.barrier.scroller.cooldown
scoreboard players reset * settings.barrier.scroller.narrowing
scoreboard objectives remove settings.barrier.scroller.narrowing
scoreboard players reset * settings.barrier.scroller.size
scoreboard objectives remove settings.barrier.scroller.size
scoreboard players reset * settings.barrier.scroller.min_size
scoreboard objectives remove settings.barrier.scroller.min_size