# EVENTS INTERACTION

function settings:pillars/parameters/spinner/team/events/button with entity @s interaction