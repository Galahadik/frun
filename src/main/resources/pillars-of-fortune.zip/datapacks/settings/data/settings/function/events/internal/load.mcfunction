# namespace: events

# REMOVE DATA
data modify storage data:settings t.parameters set value [{"name":"minutes", "type":"scroller"},{"name":"seconds", "type":"scroller"}]

# COORDINATES
function settings:events/internal/content/math/coordinates

$data modify storage data:settings t.rot set value $(rot)


# HEADER and GET Y
function settings:events/internal/content/math/get_y
function settings:events/internal/content/header with storage data:settings t

# "load_parameters": 
function settings:events/parameters/scroller/minutes/load with storage data:settings t
function settings:events/parameters/scroller/seconds/load with storage data:settings t

# FOOTER and GET Y
function settings:events/internal/content/math/get_y
function settings:events/internal/content/footer with storage data:settings t

# REMOVE DATA
data remove storage data:settings t