execute store result entity @s data.current_id int 1 run scoreboard players get #value settings.effect_kill.spinner.unequip

function settings:effect_kill/parameters/spinner/unequip/interaction/update/set_button with entity @s data

execute store result score #max settings.effect_kill.spinner.unequip run data get entity @s data.buttons