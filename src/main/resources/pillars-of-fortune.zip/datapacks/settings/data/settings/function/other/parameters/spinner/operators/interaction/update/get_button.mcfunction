execute store result entity @s data.current_id int 1 run scoreboard players get #value settings.other.spinner.operators

function settings:other/parameters/spinner/operators/interaction/update/set_button with entity @s data

execute store result score #max settings.other.spinner.operators run data get entity @s data.buttons