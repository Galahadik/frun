# effect_death
# spinner
# unequip

execute as @e[ tag = settings.effect_death, tag = settings.effect_death.spinner.unequip.button.interaction, nbt={interaction:{}}] run function settings:effect_death/parameters/spinner/unequip/interaction/button