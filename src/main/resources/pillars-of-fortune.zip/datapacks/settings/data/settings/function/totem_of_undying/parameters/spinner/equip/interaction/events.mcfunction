# EVENTS INTERACTION

function settings:totem_of_undying/parameters/spinner/equip/events/equip with entity @s interaction