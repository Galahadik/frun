execute if score #max settings.items.scroller.max_count > #value settings.items.scroller.max_count run function settings:items/parameters/scroller/max_count/interaction/right_button/add
execute if score #max settings.items.scroller.max_count <= #value settings.items.scroller.max_count run scoreboard players operation #value settings.items.scroller.max_count = #max settings.items.scroller.max_count

function settings:items/parameters/scroller/max_count/interaction/update

data remove entity @s interaction