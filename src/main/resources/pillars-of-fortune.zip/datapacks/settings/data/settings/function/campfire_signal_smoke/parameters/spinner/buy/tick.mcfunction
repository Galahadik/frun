# campfire_signal_smoke
# spinner
# buy

execute as @e[ tag = settings.campfire_signal_smoke, tag = settings.campfire_signal_smoke.spinner.buy.button.interaction, nbt={interaction:{}}] run function settings:campfire_signal_smoke/parameters/spinner/buy/interaction/button