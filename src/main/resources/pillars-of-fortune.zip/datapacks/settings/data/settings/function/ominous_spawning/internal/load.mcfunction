# namespace: ominous_spawning

# REMOVE DATA
data modify storage data:settings t.parameters set value [{"name":"buy", "type":"spinner"},{"name":"equip", "type":"spinner"}]

# COORDINATES
function settings:ominous_spawning/internal/content/math/coordinates

$data modify storage data:settings t.rot set value $(rot)


# HEADER and GET Y
function settings:ominous_spawning/internal/content/math/get_y
function settings:ominous_spawning/internal/content/header with storage data:settings t

# "load_parameters": 
function settings:ominous_spawning/parameters/spinner/buy/load with storage data:settings t
function settings:ominous_spawning/parameters/spinner/equip/load with storage data:settings t

# FOOTER and GET Y
function settings:ominous_spawning/internal/content/math/get_y
function settings:ominous_spawning/internal/content/footer with storage data:settings t

# REMOVE DATA
data remove storage data:settings t