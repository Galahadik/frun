execute store result entity @s data.current_id int 1 run scoreboard players get #value settings.campfire_signal_smoke.spinner.buy

function settings:campfire_signal_smoke/parameters/spinner/buy/interaction/update/set_button with entity @s data

execute store result score #max settings.campfire_signal_smoke.spinner.buy run data get entity @s data.buttons