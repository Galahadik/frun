scoreboard players add #value settings.campfire_signal_smoke.spinner.equip 1
execute if score #value settings.campfire_signal_smoke.spinner.equip >= #max settings.campfire_signal_smoke.spinner.equip run scoreboard players set #value settings.campfire_signal_smoke.spinner.equip 0

function settings:campfire_signal_smoke/parameters/spinner/equip/interaction/update/update_button

function settings:campfire_signal_smoke/parameters/spinner/equip/interaction/events

data remove entity @s interaction