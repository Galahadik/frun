$execute as @a run title @s title [{"text": "$(visible_name)", "color": "red"}]
execute as @a run title @s subtitle [{"text": "ивент в мире", "color": "white"}]

$scoreboard objectives add events.$(name) dummy