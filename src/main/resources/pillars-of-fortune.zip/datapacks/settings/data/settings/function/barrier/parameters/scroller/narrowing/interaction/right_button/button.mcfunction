execute if score #max settings.barrier.scroller.narrowing > #value settings.barrier.scroller.narrowing run function settings:barrier/parameters/scroller/narrowing/interaction/right_button/add
execute if score #max settings.barrier.scroller.narrowing <= #value settings.barrier.scroller.narrowing run scoreboard players operation #value settings.barrier.scroller.narrowing = #max settings.barrier.scroller.narrowing

function settings:barrier/parameters/scroller/narrowing/interaction/update

data remove entity @s interaction