execute as @e[  tag = settings.items, tag = settings.items.scroller.min_count.placeholder ] run data modify entity @s text set value [{"score": {"objective": "settings.items.scroller.min_count", "name": "#value"}, "color": "#ababab"}]

execute as @e[  tag = settings.items, tag = settings.items.scroller.min_count.buttons.left ] run data modify entity @s background set value -3727585
execute as @e[  tag = settings.items, tag = settings.items.scroller.min_count.buttons.right ] run data modify entity @s background set value -8337633

execute if score #min settings.items.scroller.min_count = #value settings.items.scroller.min_count as @e[  tag = settings.items, tag = settings.items.scroller.min_count.buttons.left ] run data modify entity @s background set value -5526613
execute if score #max settings.items.scroller.min_count = #value settings.items.scroller.min_count as @e[  tag = settings.items, tag = settings.items.scroller.min_count.buttons.right ] run data modify entity @s background set value -5526613



execute store result storage settings:pillars t.items.min_count int 1 run scoreboard players get #value settings.items.scroller.min_count