execute store result storage data:settings t.num_parameters int 1 run data get storage data:settings t.parameters

execute store result score #num_parameters settings.math run data get storage data:settings t.num_parameters

scoreboard players set 2 settings.math 2
scoreboard players set 1 settings.math 1
scoreboard players set 0 settings.math 0

scoreboard players operation #num_parameters settings.math += 2 settings.math

function settings:ominous_spawning/internal/content/math/loop