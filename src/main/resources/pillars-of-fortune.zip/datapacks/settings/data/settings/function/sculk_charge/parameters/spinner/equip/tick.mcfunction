# sculk_charge
# spinner
# equip

execute as @e[ tag = settings.sculk_charge, tag = settings.sculk_charge.spinner.equip.button.interaction, nbt={interaction:{}}] run function settings:sculk_charge/parameters/spinner/equip/interaction/button