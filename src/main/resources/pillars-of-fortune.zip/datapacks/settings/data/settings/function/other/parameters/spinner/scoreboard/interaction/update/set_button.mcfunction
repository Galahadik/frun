# other
# spinner
# scoreboard

$data modify entity @s data.current_button set from entity @s data.buttons[$(current_id)]
$data modify entity @s data.current_appearance set from entity @s data.appearance[$(current_id)]

data modify entity @s text set from entity @s data.current_button

function settings:other/parameters/spinner/scoreboard/interaction/update/set_appearance with entity @s data.current_appearance

# RETURN


execute store result storage settings:pillars t.other.scoreboard int 1 run scoreboard players get #value settings.other.spinner.scoreboard