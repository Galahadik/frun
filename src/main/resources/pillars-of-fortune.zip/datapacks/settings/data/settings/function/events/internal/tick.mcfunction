# "tick_parameters": 
function settings:events/parameters/scroller/minutes/tick
function settings:events/parameters/scroller/seconds/tick