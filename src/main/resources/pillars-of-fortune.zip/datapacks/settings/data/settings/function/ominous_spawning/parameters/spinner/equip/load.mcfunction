# namespace: ominous_spawning
# name: equip
# type: spinner

# content.buttons_appearance: {"background":"-5658199", "shadow":"False"}
# content.buttons_content: {"text": "[экипировать]", "color": "black"}

# content.components.initial: 0

scoreboard objectives add settings.ominous_spawning.spinner.equip dummy

scoreboard players set #value settings.ominous_spawning.spinner.equip 0

execute store result score #max settings.ominous_spawning.spinner.equip run data get entity @s data.buttons

# GET Y
function settings:ominous_spawning/internal/content/math/get_y

# CONTENT
function settings:ominous_spawning/parameters/spinner/equip/content with storage data:settings t