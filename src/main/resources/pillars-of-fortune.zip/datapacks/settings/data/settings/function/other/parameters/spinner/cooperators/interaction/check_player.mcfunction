$execute as @a[ nbt = { UUID: $(player) } ] at @s run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 1 1

$tellraw @a[ nbt = { UUID: $(player) } ] [{"text": " \n Вы не являетесь оператором или кооператором, чтобы изменять данную настройку.\n ", "color": "red"}]

data remove entity @s interaction