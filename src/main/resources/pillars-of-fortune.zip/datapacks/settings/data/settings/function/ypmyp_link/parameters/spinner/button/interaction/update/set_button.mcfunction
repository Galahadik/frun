# ypmyp_link
# spinner
# button

$data modify entity @s data.current_button set from entity @s data.buttons[$(current_id)]
$data modify entity @s data.current_appearance set from entity @s data.appearance[$(current_id)]

data modify entity @s text set from entity @s data.current_button

function settings:ypmyp_link/parameters/spinner/button/interaction/update/set_appearance with entity @s data.current_appearance

# RETURN

