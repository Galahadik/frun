# ominous_spawning
kill @e[ tag = settings.ominous_spawning ]

scoreboard players reset * settings.ominous_spawning.spinner.buy
scoreboard objectives remove settings.ominous_spawning.spinner.buy
scoreboard players reset * settings.ominous_spawning.spinner.equip
scoreboard objectives remove settings.ominous_spawning.spinner.equip