execute store result entity @s data.current_id int 1 run scoreboard players get #value settings.large_smoke.spinner.buy

function settings:large_smoke/parameters/spinner/buy/interaction/update/set_button with entity @s data

execute store result score #max settings.large_smoke.spinner.buy run data get entity @s data.buttons