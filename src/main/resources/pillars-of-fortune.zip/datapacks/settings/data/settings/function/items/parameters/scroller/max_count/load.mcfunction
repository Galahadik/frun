# namespace: items
# name: max_count
# type: scroller

# content.components.max: 999
# content.components.min: 1
# content.components.step: 1
# content.components.initial: 1

scoreboard objectives add settings.items.scroller.max_count dummy

scoreboard players set #max settings.items.scroller.max_count 999
scoreboard players set #min settings.items.scroller.max_count 1
scoreboard players set #step settings.items.scroller.max_count 1
scoreboard players set #value settings.items.scroller.max_count 1

# GET Y
function settings:items/internal/content/math/get_y

# CONTENT
function settings:items/parameters/scroller/max_count/content with storage data:settings t

# UPDATE
function settings:items/parameters/scroller/max_count/interaction/update