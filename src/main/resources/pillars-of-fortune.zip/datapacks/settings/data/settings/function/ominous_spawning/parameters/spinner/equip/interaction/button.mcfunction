scoreboard players add #value settings.ominous_spawning.spinner.equip 1
execute if score #value settings.ominous_spawning.spinner.equip >= #max settings.ominous_spawning.spinner.equip run scoreboard players set #value settings.ominous_spawning.spinner.equip 0

function settings:ominous_spawning/parameters/spinner/equip/interaction/update/update_button

function settings:ominous_spawning/parameters/spinner/equip/interaction/events

data remove entity @s interaction