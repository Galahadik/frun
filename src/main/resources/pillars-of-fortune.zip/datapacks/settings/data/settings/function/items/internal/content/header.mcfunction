# CONTENT

# content.components.compound: [{"text": "ɪᴛᴇᴍꜱ", "color": "white"}]
# content.components.width: "                         "

# content.appearance.header.background: -15066852
# content.appearance.compound.background: 0
# content.appearance.compound.shadow: False

# REMOVE CURRENT Y
function settings:items/internal/content/math/remove_y

$summon text_display ^ ^$(y_current) ^ { \
    "Tags": [ "settings.items" ], \
    \
    Passengers: [ \
        { \
            "comment": "=== COMPOUND ===", \
            "id": "minecraft:text_display", \
            \
            "text": [{"text": "ɪᴛᴇᴍꜱ", "color": "white"}], \
            "background": 0, \
            "shadow": False, \
            "Tags": [ settings.items, "settings.items.header.compound" ], \
            "Rotation": [$(rot)f, 0f] \
        }, \
        { \
            "id": "minecraft:text_display", \
            \
            "text": { "text": "                         " }, \
            "background": -15066852, \
            "Tags": [ settings.items, "settings.items.header.background" ], \
            "Rotation": [$(rot)f, 0f] \
        } \
    ] \
}