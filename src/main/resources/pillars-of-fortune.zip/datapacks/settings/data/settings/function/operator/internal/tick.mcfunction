# "tick_parameters": 
function settings:operator/parameters/spinner/button/tick