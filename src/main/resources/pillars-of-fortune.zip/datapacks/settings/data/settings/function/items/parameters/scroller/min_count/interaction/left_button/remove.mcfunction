scoreboard players operation #value settings.items.scroller.min_count -= #step settings.items.scroller.min_count

function settings:items/parameters/scroller/min_count/interaction/left_button/events