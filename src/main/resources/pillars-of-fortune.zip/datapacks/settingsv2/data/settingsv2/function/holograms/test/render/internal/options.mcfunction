$function settingsv2:holograms/test/render/ui/variables/$(type)_to_defaut
$function settingsv2:holograms/test/render/ui/options/$(type)/$(id)/load with storage data:settings temp.temp_data.option