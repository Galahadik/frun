# campfire_signal_smoke
kill @e[ tag = settings.campfire_signal_smoke ]

scoreboard players reset * settings.campfire_signal_smoke.spinner.buy
scoreboard objectives remove settings.campfire_signal_smoke.spinner.buy
scoreboard players reset * settings.campfire_signal_smoke.spinner.equip
scoreboard objectives remove settings.campfire_signal_smoke.spinner.equip