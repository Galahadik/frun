# EVENTS INTERACTION

function settings:other/parameters/spinner/operators/events/button with entity @s interaction