# INITIAL
function settingsv2:holograms/test/internal/initial

# RENDER INTERNAL
function settingsv2:holograms/test/render/internal/render