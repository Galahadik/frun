execute if score #value settings.other.spinner.cooperators matches 0 run scoreboard players set #value settings.other.spinner.operators 0

function settings:other/parameters/spinner/operators/interaction/update/update_button