#Не убирайте $(null), он предотвращает постоянное выполнение tick.mcfunction в режиме ивентов, когда его ивент не активен.
#Ивент будет работать от его активации до начала следующего ивента.
$$(null)

$function events:events/type.overworld/fire_rain/functions/limit_coordinates $(data)

$execute as @e[type=fireball] run function events:events/type.overworld/fire_rain/functions/reset $(data)