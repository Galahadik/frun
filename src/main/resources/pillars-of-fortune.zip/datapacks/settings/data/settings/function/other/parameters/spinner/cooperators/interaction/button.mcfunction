$execute unless entity @a[ nbt={ UUID: $(player) } , tag = player.operator ] run function settings:other/parameters/spinner/cooperators/interaction/check_player with entity @s interaction
$execute unless entity @a[ nbt={ UUID: $(player) } , tag = player.operator ] run return fail

scoreboard players add #value settings.other.spinner.cooperators 1
execute if score #value settings.other.spinner.cooperators >= #max settings.other.spinner.cooperators run scoreboard players set #value settings.other.spinner.cooperators 0

function settings:other/parameters/spinner/cooperators/interaction/update/update_button

function settings:other/parameters/spinner/cooperators/interaction/events

data remove entity @s interaction