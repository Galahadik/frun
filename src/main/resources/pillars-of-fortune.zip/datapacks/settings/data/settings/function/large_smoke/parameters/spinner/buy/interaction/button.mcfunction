scoreboard players add #value settings.large_smoke.spinner.buy 1
execute if score #value settings.large_smoke.spinner.buy >= #max settings.large_smoke.spinner.buy run scoreboard players set #value settings.large_smoke.spinner.buy 0

function settings:large_smoke/parameters/spinner/buy/interaction/update/update_button

function settings:large_smoke/parameters/spinner/buy/interaction/events

data remove entity @s interaction