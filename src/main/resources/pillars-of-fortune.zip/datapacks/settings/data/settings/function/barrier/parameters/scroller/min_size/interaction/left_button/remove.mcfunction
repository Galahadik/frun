scoreboard players operation #value settings.barrier.scroller.min_size -= #step settings.barrier.scroller.min_size

function settings:barrier/parameters/scroller/min_size/interaction/left_button/events