# namespace: campfire_signal_smoke
# name: equip
# type: spinner

# content.buttons_appearance: {"background":"-5658199", "shadow":"False"}
# content.buttons_content: {"text": "[экипировать]", "color": "black"}

# content.components.initial: 0

scoreboard objectives add settings.campfire_signal_smoke.spinner.equip dummy

scoreboard players set #value settings.campfire_signal_smoke.spinner.equip 0

execute store result score #max settings.campfire_signal_smoke.spinner.equip run data get entity @s data.buttons

# GET Y
function settings:campfire_signal_smoke/internal/content/math/get_y

# CONTENT
function settings:campfire_signal_smoke/parameters/spinner/equip/content with storage data:settings t