# namespace: sculk_charge
# name: equip
# type: spinner

# content.buttons_appearance: {"background":"-5658199", "shadow":"False"}
# content.buttons_content: {"text": "[экипировать]", "color": "black"}

# content.components.initial: 0

scoreboard objectives add settings.sculk_charge.spinner.equip dummy

scoreboard players set #value settings.sculk_charge.spinner.equip 0

execute store result score #max settings.sculk_charge.spinner.equip run data get entity @s data.buttons

# GET Y
function settings:sculk_charge/internal/content/math/get_y

# CONTENT
function settings:sculk_charge/parameters/spinner/equip/content with storage data:settings t