data modify storage data:settings temp.temp_data.option set from storage data:settings temp.data.options[0]

data remove storage data:settings temp.data.options[0]

function settingsv2:holograms/test/render/internal/options with storage data:settings temp.temp_data.option

execute if data storage data:settings temp.data.options[0] run function settingsv2:holograms/test/render/internal/render