# CONTENT

# content.components.compound: [{"text": "ᴏᴛʜᴇʀ", "color": "white"}]
# content.components.width: "                         "

# content.appearance.header.background: -15066852
# content.appearance.compound.background: 0
# content.appearance.compound.shadow: False

# REMOVE CURRENT Y
function settings:other/internal/content/math/remove_y

$summon text_display ^ ^$(y_current) ^ { \
    "Tags": [ "settings.other" ], \
    \
    Passengers: [ \
        { \
            "comment": "=== COMPOUND ===", \
            "id": "minecraft:text_display", \
            \
            "text": [{"text": "ᴏᴛʜᴇʀ", "color": "white"}], \
            "background": 0, \
            "shadow": False, \
            "Tags": [ settings.other, "settings.other.header.compound" ], \
            "Rotation": [$(rot)f, 0f] \
        }, \
        { \
            "id": "minecraft:text_display", \
            \
            "text": { "text": "                         " }, \
            "background": -15066852, \
            "Tags": [ settings.other, "settings.other.header.background" ], \
            "Rotation": [$(rot)f, 0f] \
        } \
    ] \
}