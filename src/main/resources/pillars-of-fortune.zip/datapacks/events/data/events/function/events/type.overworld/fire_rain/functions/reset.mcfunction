$scoreboard players add @s events.$(name) 1

$execute if score @s events.$(name) matches 60.. run kill @s