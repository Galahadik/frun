# namespace: barrier
# name: narrowing
# type: scroller

# content.appearance.content.background: -15066852

# content.appearance.buttons.left.background: -3727585
# content.appearance.buttons.left.shadow: False

# content.appearance.buttons.right.background: -8337633
# content.appearance.buttons.right.shadow: False

# content.appearance.compound.background: 0
# content.appearance.compound.shadow: False

# content.appearance.placeholder.background: 0
# content.appearance.placeholder.shadow: False

# content.components.buttons.left: [{"text": "[-]", "color": "black"}]
# content.components.buttons.right: [{"text": "[+]", "color": "black"}]
# content.components.compound: [{"text": "сужение", "color": "white"}]
# content.components.placeholder: [{"score": {"objective": "settings.barrier.scroller.narrowing", "name": "#value"}, "color": "#ababab"}, {"text": "б", "color": "#ababab"}]

# content.components.max: 999
# content.components.min: 0
# content.components.step: 1
# content.components.initial: 2

# content.components.content.width: "                         "

# REMOVE CURRENT Y
function settings:barrier/internal/content/math/remove_y

$summon text_display ^ ^$(y_current) ^ { \
    "Tags": [ "settings.barrier" ], \
    \
    Passengers: [ \
        { \
            "comment": "=== COMPOUND ===", \
            "id": "minecraft:text_display", \
            \
            "text": [{"text": "сужение", "color": "white"}], \
            "background": 0, \
            "shadow": False, \
            "Tags": [ "settings.barrier", "settings.barrier.scroller.narrowing.compound" ], \
            "transformation": { \
                "translation": [0, 0.4, 0.01], \
                "scale": [1, 1, 1], \
                "left_rotation": [0, 0, 0, 1], \
                "right_rotation": [0, 0, 0, 1] \
            }, \
            "Rotation": [$(rot)f, 0f] \
        }, \
        { \
            "comment": "=== PLACEHOLDER ===", \
            "id": "minecraft:text_display", \
            \
            "text":  [{"score": {"objective": "settings.barrier.scroller.narrowing", "name": "#value"}, "color": "#ababab"}, {"text": "б", "color": "#ababab"}], \
            "background": 0, \
            "shadow": False, \
            "Tags": [ "settings.barrier", "settings.barrier.scroller.narrowing.placeholder" ], \
            "transformation": { \
                "translation": [0, 0.1, 0.01], \
                "scale": [1, 1, 1], \
                "left_rotation": [0, 0, 0, 1], \
                "right_rotation": [0, 0, 0, 1] \
            }, \
            "Rotation": [$(rot)f, 0f] \
        }, \
        { \
            "comment": "=== BUTTONS LEFT ===", \
            "id": "minecraft:text_display", \
            \
            "text": [{"text": "[-]", "color": "black"}], \
            "background": -3727585, \
            "shadow": False, \
            "Tags": [ "settings.barrier", "settings.barrier.scroller.narrowing.buttons.left" ], \
            "transformation": { \
                "translation": [-1, 0.1, 0.01], \
                "scale": [1, 1, 1], \
                "left_rotation": [0, 0, 0, 1], \
                "right_rotation": [0, 0, 0, 1] \
            }, \
            "Rotation": [$(rot)f, 0f] \
        }, \
        { \
            "comment": "=== BUTTONS RIGHT ===", \
            "id": "minecraft:text_display", \
            \
            "text": [{"text": "[+]", "color": "black"}], \
            "background": -8337633, \
            "shadow": False, \
            "Tags": [ "settings.barrier", "settings.barrier.scroller.narrowing.buttons.right" ], \
            "transformation": { \
                "translation": [1, 0.1, 0.01], \
                "scale": [1, 1, 1], \
                "left_rotation": [0, 0, 0, 1], \
                "right_rotation": [0, 0, 0, 1] \
            }, \
            "Rotation": [$(rot)f, 0f] \
        }, \
        { \
            "comment": "=== BACKGROUND ===", \
            "id": "minecraft:text_display", \
            \
            "text": { "text": "                         " }, \
            "background": -15066852, \
            "Tags": [ "settings.barrier", "settings.barrier.scroller.narrowing.background" ], \
            "transformation": { \
                "translation": [0, 0, 0], \
                "scale": [1, 3, 1], \
                "left_rotation": [0, 0, 0, 1], \
                "right_rotation": [0, 0, 0, 1] \
            }, \
            "Rotation": [$(rot)f, 0f] \
        } \
    ] \
}

$summon interaction ^1 ^$(y_current) ^ { \
    "Tags": [ "settings.barrier", "settings.barrier.scroller.narrowing.buttons.left.interaction" ], \
    "width": 0.25f, \
    "height": 0.25f \
}
execute as @e[ tag = settings.barrier, tag = settings.barrier.scroller.narrowing.buttons.left.interaction ] at @e[ tag = settings.barrier, tag = settings.barrier.scroller.narrowing.buttons.left ] run tp @s ^-1 ^0.1 ^

$summon interaction ^-1 ^$(y_current) ^ { \
    "Tags": [ "settings.barrier", "settings.barrier.scroller.narrowing.buttons.right.interaction" ], \
    "width": 0.25f, \
    "height": 0.25f \
}
execute as @e[ tag = settings.barrier, tag = settings.barrier.scroller.narrowing.buttons.right.interaction ] at @e[ tag = settings.barrier, tag = settings.barrier.scroller.narrowing.buttons.right ] run tp @s ^1 ^0.1 ^