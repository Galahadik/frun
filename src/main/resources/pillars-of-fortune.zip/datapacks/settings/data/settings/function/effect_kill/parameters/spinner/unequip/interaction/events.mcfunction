# EVENTS INTERACTION

function settings:effect_kill/parameters/spinner/unequip/events/unequip with entity @s interaction