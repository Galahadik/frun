# barrier
# scroller
# narrowing

execute as @e[ tag = settings.barrier, tag = settings.barrier.scroller.narrowing.buttons.left.interaction, nbt={interaction:{}}] run function settings:barrier/parameters/scroller/narrowing/interaction/left_button/button

execute as @e[ tag = settings.barrier, tag = settings.barrier.scroller.narrowing.buttons.right.interaction, nbt={interaction:{}}] run function settings:barrier/parameters/scroller/narrowing/interaction/right_button/button