execute store result storage data:settings t.y_element int 1 run scoreboard players operation #num_parameters settings.math -= 1 settings.math

execute store result storage data:settings t.y_element float 0.78 run data get storage data:settings t.y_element

data modify storage data:settings t.y_elements append from storage data:settings t.y_element

execute if score #num_parameters settings.math > 0 settings.math run function settings:gust_emitter/internal/content/math/loop
execute if score #num_parameters settings.math = 0 settings.math run data modify storage data:settings t.y_elements[-1] set value 0.5