# namespace: effect_death

# REMOVE DATA
data modify storage data:settings t.parameters set value [{"name":"unequip", "type":"spinner"}]

# COORDINATES
function settings:effect_death/internal/content/math/coordinates

$data modify storage data:settings t.rot set value $(rot)


# HEADER and GET Y
function settings:effect_death/internal/content/math/get_y
function settings:effect_death/internal/content/header with storage data:settings t

# "load_parameters": 
function settings:effect_death/parameters/spinner/unequip/load with storage data:settings t

# FOOTER and GET Y
function settings:effect_death/internal/content/math/get_y
function settings:effect_death/internal/content/footer with storage data:settings t

# REMOVE DATA
data remove storage data:settings t