# barrier
# scroller
# cooldown

execute as @e[ tag = settings.barrier, tag = settings.barrier.scroller.cooldown.buttons.left.interaction, nbt={interaction:{}}] run function settings:barrier/parameters/scroller/cooldown/interaction/left_button/button

execute as @e[ tag = settings.barrier, tag = settings.barrier.scroller.cooldown.buttons.right.interaction, nbt={interaction:{}}] run function settings:barrier/parameters/scroller/cooldown/interaction/right_button/button