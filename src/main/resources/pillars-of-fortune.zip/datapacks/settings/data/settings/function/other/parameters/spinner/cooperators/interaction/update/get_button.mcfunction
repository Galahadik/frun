execute store result entity @s data.current_id int 1 run scoreboard players get #value settings.other.spinner.cooperators

function settings:other/parameters/spinner/cooperators/interaction/update/set_button with entity @s data

execute store result score #max settings.other.spinner.cooperators run data get entity @s data.buttons