scoreboard players add #value settings.operator.spinner.button 1
execute if score #value settings.operator.spinner.button >= #max settings.operator.spinner.button run scoreboard players set #value settings.operator.spinner.button 0

function settings:operator/parameters/spinner/button/interaction/update/update_button

function settings:operator/parameters/spinner/button/interaction/events

data remove entity @s interaction