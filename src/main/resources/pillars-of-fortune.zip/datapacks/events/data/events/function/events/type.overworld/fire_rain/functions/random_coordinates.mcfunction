$execute store result score #z events.$(name) run random value $(z_z)..$(x_z)
$execute store result score #x events.$(name) run random value $(z_x)..$(x_x)

# ХРАНИЛИЩА
$execute store result storage data:events t.events.fire_rain.x int 1 run scoreboard players get #x events.$(name)
$execute store result storage data:events t.events.fire_rain.z int 1 run scoreboard players get #z events.$(name)

function events:events/type.overworld/fire_rain/functions/spawn_fireball with storage data:events t.events.fire_rain