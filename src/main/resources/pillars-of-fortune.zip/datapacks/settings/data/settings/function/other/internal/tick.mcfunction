# "tick_parameters": 
function settings:other/parameters/spinner/scoreboard/tick
function settings:other/parameters/spinner/operators/tick
function settings:other/parameters/spinner/cooperators/tick