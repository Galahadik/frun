execute store result entity @s data.current_id int 1 run scoreboard players get #value settings.ominous_spawning.spinner.equip

function settings:ominous_spawning/parameters/spinner/equip/interaction/update/set_button with entity @s data

execute store result score #max settings.ominous_spawning.spinner.equip run data get entity @s data.buttons