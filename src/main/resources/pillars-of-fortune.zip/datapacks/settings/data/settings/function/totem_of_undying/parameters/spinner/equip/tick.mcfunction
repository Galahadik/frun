# totem_of_undying
# spinner
# equip

execute as @e[ tag = settings.totem_of_undying, tag = settings.totem_of_undying.spinner.equip.button.interaction, nbt={interaction:{}}] run function settings:totem_of_undying/parameters/spinner/equip/interaction/button