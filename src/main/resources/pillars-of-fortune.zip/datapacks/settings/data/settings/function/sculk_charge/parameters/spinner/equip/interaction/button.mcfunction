scoreboard players add #value settings.sculk_charge.spinner.equip 1
execute if score #value settings.sculk_charge.spinner.equip >= #max settings.sculk_charge.spinner.equip run scoreboard players set #value settings.sculk_charge.spinner.equip 0

function settings:sculk_charge/parameters/spinner/equip/interaction/update/update_button

function settings:sculk_charge/parameters/spinner/equip/interaction/events

data remove entity @s interaction