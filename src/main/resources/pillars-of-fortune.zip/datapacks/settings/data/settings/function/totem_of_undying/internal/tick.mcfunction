# "tick_parameters": 
function settings:totem_of_undying/parameters/spinner/buy/tick
function settings:totem_of_undying/parameters/spinner/equip/tick