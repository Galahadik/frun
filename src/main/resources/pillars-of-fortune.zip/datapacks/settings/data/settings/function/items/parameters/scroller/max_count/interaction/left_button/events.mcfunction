# EVENTS INTERACTION

function settings:items/parameters/scroller/max_count/events/max_count with entity @s interaction