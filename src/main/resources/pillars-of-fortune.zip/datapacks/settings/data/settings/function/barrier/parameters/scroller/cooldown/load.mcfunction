# namespace: barrier
# name: cooldown
# type: scroller

# content.components.max: 999
# content.components.min: 1
# content.components.step: 1
# content.components.initial: 10

scoreboard objectives add settings.barrier.scroller.cooldown dummy

scoreboard players set #max settings.barrier.scroller.cooldown 999
scoreboard players set #min settings.barrier.scroller.cooldown 1
scoreboard players set #step settings.barrier.scroller.cooldown 1
scoreboard players set #value settings.barrier.scroller.cooldown 10

# GET Y
function settings:barrier/internal/content/math/get_y

# CONTENT
function settings:barrier/parameters/scroller/cooldown/content with storage data:settings t

# UPDATE
function settings:barrier/parameters/scroller/cooldown/interaction/update