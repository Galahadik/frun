# large_smoke
# spinner
# buy

execute as @e[ tag = settings.large_smoke, tag = settings.large_smoke.spinner.buy.button.interaction, nbt={interaction:{}}] run function settings:large_smoke/parameters/spinner/buy/interaction/button