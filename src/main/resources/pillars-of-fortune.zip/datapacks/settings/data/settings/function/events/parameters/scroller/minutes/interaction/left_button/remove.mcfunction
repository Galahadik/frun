scoreboard players operation #value settings.events.scroller.minutes -= #step settings.events.scroller.minutes

function settings:events/parameters/scroller/minutes/interaction/left_button/events