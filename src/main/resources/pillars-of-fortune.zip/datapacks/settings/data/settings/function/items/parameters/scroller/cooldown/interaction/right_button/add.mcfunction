scoreboard players operation #value settings.items.scroller.cooldown += #step settings.items.scroller.cooldown

function settings:items/parameters/scroller/cooldown/interaction/right_button/events