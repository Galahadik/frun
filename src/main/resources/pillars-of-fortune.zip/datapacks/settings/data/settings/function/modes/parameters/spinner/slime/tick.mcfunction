# modes
# spinner
# slime

execute as @e[ tag = settings.modes, tag = settings.modes.spinner.slime.button.interaction, nbt={interaction:{}}] run function settings:modes/parameters/spinner/slime/interaction/button