# "tick_parameters": 
function settings:gust_emitter/parameters/spinner/buy/tick
function settings:gust_emitter/parameters/spinner/equip/tick