# totem_of_undying
kill @e[ tag = settings.totem_of_undying ]

scoreboard players reset * settings.totem_of_undying.spinner.buy
scoreboard objectives remove settings.totem_of_undying.spinner.buy
scoreboard players reset * settings.totem_of_undying.spinner.equip
scoreboard objectives remove settings.totem_of_undying.spinner.equip