# EVENTS INTERACTION

function settings:large_smoke/parameters/spinner/buy/events/buy with entity @s interaction