# other
# spinner
# cooperators

execute as @e[ tag = settings.other, tag = settings.other.spinner.cooperators.button.interaction, nbt={interaction:{}}] run function settings:other/parameters/spinner/cooperators/interaction/button with entity @s interaction