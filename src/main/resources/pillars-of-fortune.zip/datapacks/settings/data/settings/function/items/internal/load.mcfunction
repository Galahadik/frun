# namespace: items

# REMOVE DATA
data modify storage data:settings t.parameters set value [{"name":"cooldown", "type":"scroller"},{"name":"min_count", "type":"scroller"},{"name":"max_count", "type":"scroller"}]

# COORDINATES
function settings:items/internal/content/math/coordinates

$data modify storage data:settings t.rot set value $(rot)


# HEADER and GET Y
function settings:items/internal/content/math/get_y
function settings:items/internal/content/header with storage data:settings t

# "load_parameters": 
function settings:items/parameters/scroller/cooldown/load with storage data:settings t
function settings:items/parameters/scroller/min_count/load with storage data:settings t
function settings:items/parameters/scroller/max_count/load with storage data:settings t

# FOOTER and GET Y
function settings:items/internal/content/math/get_y
function settings:items/internal/content/footer with storage data:settings t

# REMOVE DATA
data remove storage data:settings t