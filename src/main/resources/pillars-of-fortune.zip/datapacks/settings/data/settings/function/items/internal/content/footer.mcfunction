# CONTENT

# content.components.content.width: "                         "

# content.appearance.footer.background: -15066852

# FOOTER
$summon text_display ~ ~$(y_current) ~ { \
    "text": { "text": "                         " }, \
    "background": -15066852, \
    "Tags": [ settings.items, "settings.items.footer.background" ], \
    "Rotation": [$(rot)f, 0f] \
}