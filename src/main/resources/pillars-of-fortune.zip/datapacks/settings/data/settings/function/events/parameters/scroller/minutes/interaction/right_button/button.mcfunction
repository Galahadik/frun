execute if score #max settings.events.scroller.minutes > #value settings.events.scroller.minutes run function settings:events/parameters/scroller/minutes/interaction/right_button/add
execute if score #max settings.events.scroller.minutes <= #value settings.events.scroller.minutes run scoreboard players operation #value settings.events.scroller.minutes = #max settings.events.scroller.minutes

function settings:events/parameters/scroller/minutes/interaction/update

data remove entity @s interaction