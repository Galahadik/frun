scoreboard players add #value settings.totem_of_undying.spinner.buy 1
execute if score #value settings.totem_of_undying.spinner.buy >= #max settings.totem_of_undying.spinner.buy run scoreboard players set #value settings.totem_of_undying.spinner.buy 0

function settings:totem_of_undying/parameters/spinner/buy/interaction/update/update_button

function settings:totem_of_undying/parameters/spinner/buy/interaction/events

data remove entity @s interaction