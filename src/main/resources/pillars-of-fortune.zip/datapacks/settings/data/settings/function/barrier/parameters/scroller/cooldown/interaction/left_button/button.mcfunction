execute if score #min settings.barrier.scroller.cooldown < #value settings.barrier.scroller.cooldown run function settings:barrier/parameters/scroller/cooldown/interaction/left_button/remove
execute if score #min settings.barrier.scroller.cooldown >= #value settings.barrier.scroller.cooldown run scoreboard players operation #value settings.barrier.scroller.cooldown = #min settings.barrier.scroller.cooldown

function settings:barrier/parameters/scroller/cooldown/interaction/update

data remove entity @s interaction