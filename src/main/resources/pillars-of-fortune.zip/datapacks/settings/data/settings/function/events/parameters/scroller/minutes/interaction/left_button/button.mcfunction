execute if score #min settings.events.scroller.minutes < #value settings.events.scroller.minutes run function settings:events/parameters/scroller/minutes/interaction/left_button/remove
execute if score #min settings.events.scroller.minutes >= #value settings.events.scroller.minutes run scoreboard players operation #value settings.events.scroller.minutes = #min settings.events.scroller.minutes

function settings:events/parameters/scroller/minutes/interaction/update

data remove entity @s interaction