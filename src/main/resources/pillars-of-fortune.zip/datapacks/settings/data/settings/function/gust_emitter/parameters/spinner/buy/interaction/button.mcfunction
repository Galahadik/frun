scoreboard players add #value settings.gust_emitter.spinner.buy 1
execute if score #value settings.gust_emitter.spinner.buy >= #max settings.gust_emitter.spinner.buy run scoreboard players set #value settings.gust_emitter.spinner.buy 0

function settings:gust_emitter/parameters/spinner/buy/interaction/update/update_button

function settings:gust_emitter/parameters/spinner/buy/interaction/events

data remove entity @s interaction