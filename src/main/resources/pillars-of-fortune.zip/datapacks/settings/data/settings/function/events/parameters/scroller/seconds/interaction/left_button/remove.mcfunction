scoreboard players operation #value settings.events.scroller.seconds -= #step settings.events.scroller.seconds

function settings:events/parameters/scroller/seconds/interaction/left_button/events