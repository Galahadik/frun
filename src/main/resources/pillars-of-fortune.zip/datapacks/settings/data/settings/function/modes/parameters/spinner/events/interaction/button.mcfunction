scoreboard players add #value settings.modes.spinner.events 1
execute if score #value settings.modes.spinner.events >= #max settings.modes.spinner.events run scoreboard players set #value settings.modes.spinner.events 0

function settings:modes/parameters/spinner/events/interaction/update/update_button

function settings:modes/parameters/spinner/events/interaction/events

data remove entity @s interaction