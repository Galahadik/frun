# EVENTS INTERACTION

function settings:sculk_charge/parameters/spinner/buy/events/buy with entity @s interaction