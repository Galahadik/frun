execute if score #value settings.items.scroller.max_count < #value settings.items.scroller.min_count run scoreboard players operation #value settings.items.scroller.max_count = #value settings.items.scroller.min_count

function settings:items/parameters/scroller/max_count/interaction/update