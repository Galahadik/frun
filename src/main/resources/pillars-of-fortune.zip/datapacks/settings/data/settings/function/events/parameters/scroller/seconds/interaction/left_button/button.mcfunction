execute if score #min settings.events.scroller.seconds < #value settings.events.scroller.seconds run function settings:events/parameters/scroller/seconds/interaction/left_button/remove
execute if score #min settings.events.scroller.seconds >= #value settings.events.scroller.seconds run scoreboard players operation #value settings.events.scroller.seconds = #min settings.events.scroller.seconds

function settings:events/parameters/scroller/seconds/interaction/update

data remove entity @s interaction