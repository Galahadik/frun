$execute as @a run title @s title [{"text": "$(visible_name)", "color": "red"}]
title @a subtitle [{"text":"над игроком, "}, {"selector": "@s", }, {"text": ", произошёл ивент", "color": "white"}]

effect give @s regeneration 1 255 true
effect give @s saturation 1 255 true