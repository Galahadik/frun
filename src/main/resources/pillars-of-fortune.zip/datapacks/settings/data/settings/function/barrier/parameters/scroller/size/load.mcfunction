# namespace: barrier
# name: size
# type: scroller

# content.components.max: 250
# content.components.min: 10
# content.components.step: 2
# content.components.initial: 150

scoreboard objectives add settings.barrier.scroller.size dummy

scoreboard players set #max settings.barrier.scroller.size 250
scoreboard players set #min settings.barrier.scroller.size 10
scoreboard players set #step settings.barrier.scroller.size 2
scoreboard players set #value settings.barrier.scroller.size 150

# GET Y
function settings:barrier/internal/content/math/get_y

# CONTENT
function settings:barrier/parameters/scroller/size/content with storage data:settings t

# UPDATE
function settings:barrier/parameters/scroller/size/interaction/update