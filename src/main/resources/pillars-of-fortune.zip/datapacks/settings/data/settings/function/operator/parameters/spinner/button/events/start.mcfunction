# ASSIGN OPERATOR

$data modify storage data:operator t.operator set value $(player)
$tag @a[nbt={UUID:$(player)}] add player.operator

function settings:operator/internal/unload

function spark:server/player_count/load