# other
kill @e[ tag = settings.other ]

scoreboard players reset * settings.other.spinner.scoreboard
scoreboard objectives remove settings.other.spinner.scoreboard
scoreboard players reset * settings.other.spinner.operators
scoreboard objectives remove settings.other.spinner.operators
scoreboard players reset * settings.other.spinner.cooperators
scoreboard objectives remove settings.other.spinner.cooperators