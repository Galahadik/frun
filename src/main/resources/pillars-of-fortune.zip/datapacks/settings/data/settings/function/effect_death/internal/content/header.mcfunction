# CONTENT

# content.components.compound: [{"text": "ᴘʟᴀʏᴇʀ ᴅᴇᴀᴛʜ", "color": "white"}]
# content.components.width: "                         "

# content.appearance.header.background: -15066852
# content.appearance.compound.background: 0
# content.appearance.compound.shadow: False

# REMOVE CURRENT Y
function settings:effect_death/internal/content/math/remove_y

$summon text_display ^ ^$(y_current) ^ { \
    "Tags": [ "settings.effect_death" ], \
    \
    Passengers: [ \
        { \
            "comment": "=== COMPOUND ===", \
            "id": "minecraft:text_display", \
            \
            "text": [{"text": "ᴘʟᴀʏᴇʀ ᴅᴇᴀᴛʜ", "color": "white"}], \
            "background": 0, \
            "shadow": False, \
            "Tags": [ settings.effect_death, "settings.effect_death.header.compound" ], \
            "Rotation": [$(rot)f, 0f] \
        }, \
        { \
            "id": "minecraft:text_display", \
            \
            "text": { "text": "                         " }, \
            "background": -15066852, \
            "Tags": [ settings.effect_death, "settings.effect_death.header.background" ], \
            "Rotation": [$(rot)f, 0f] \
        } \
    ] \
}