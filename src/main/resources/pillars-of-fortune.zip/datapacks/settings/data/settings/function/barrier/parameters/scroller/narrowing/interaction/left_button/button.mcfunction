execute if score #min settings.barrier.scroller.narrowing < #value settings.barrier.scroller.narrowing run function settings:barrier/parameters/scroller/narrowing/interaction/left_button/remove
execute if score #min settings.barrier.scroller.narrowing >= #value settings.barrier.scroller.narrowing run scoreboard players operation #value settings.barrier.scroller.narrowing = #min settings.barrier.scroller.narrowing

function settings:barrier/parameters/scroller/narrowing/interaction/update

data remove entity @s interaction