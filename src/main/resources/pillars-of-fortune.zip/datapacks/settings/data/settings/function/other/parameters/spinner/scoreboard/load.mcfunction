# namespace: other
# name: scoreboard
# type: spinner

# content.buttons_appearance: {"background":"-470467", "shadow":"False"},{"background":"-470467", "shadow":"False"},{"background":"-3727585", "shadow":"False"}
# content.buttons_content: {"text": "[подробно]", "color": "black"},{"text": "[компактно]", "color": "black"},{"text": "[выключено]", "color": "black"}

# content.components.initial: 0

scoreboard objectives add settings.other.spinner.scoreboard dummy

scoreboard players set #value settings.other.spinner.scoreboard 0

execute store result score #max settings.other.spinner.scoreboard run data get entity @s data.buttons

# GET Y
function settings:other/internal/content/math/get_y

# CONTENT
function settings:other/parameters/spinner/scoreboard/content with storage data:settings t