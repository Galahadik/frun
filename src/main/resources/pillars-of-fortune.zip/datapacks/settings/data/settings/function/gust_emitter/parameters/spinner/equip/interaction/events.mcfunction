# EVENTS INTERACTION

function settings:gust_emitter/parameters/spinner/equip/events/equip with entity @s interaction