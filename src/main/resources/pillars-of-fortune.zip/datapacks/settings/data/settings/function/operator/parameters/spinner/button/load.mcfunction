# namespace: operator
# name: button
# type: spinner

# content.buttons_appearance: {"background":"-273091", "shadow":"False"}
# content.buttons_content: {"text": "[назначить]", "color": "black"}

# content.components.initial: 0

scoreboard objectives add settings.operator.spinner.button dummy

scoreboard players set #value settings.operator.spinner.button 0

execute store result score #max settings.operator.spinner.button run data get entity @s data.buttons

# GET Y
function settings:operator/internal/content/math/get_y

# CONTENT
function settings:operator/parameters/spinner/button/content with storage data:settings t