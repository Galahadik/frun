# events
# scroller
# seconds

execute as @e[ tag = settings.events, tag = settings.events.scroller.seconds.buttons.left.interaction, nbt={interaction:{}}] run function settings:events/parameters/scroller/seconds/interaction/left_button/button

execute as @e[ tag = settings.events, tag = settings.events.scroller.seconds.buttons.right.interaction, nbt={interaction:{}}] run function settings:events/parameters/scroller/seconds/interaction/right_button/button