scoreboard players add #value settings.large_smoke.spinner.equip 1
execute if score #value settings.large_smoke.spinner.equip >= #max settings.large_smoke.spinner.equip run scoreboard players set #value settings.large_smoke.spinner.equip 0

function settings:large_smoke/parameters/spinner/equip/interaction/update/update_button

function settings:large_smoke/parameters/spinner/equip/interaction/events

data remove entity @s interaction