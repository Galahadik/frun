# namespace: gust_emitter
# name: buy
# type: spinner

# content.buttons_appearance: {"background":"-8403681", "shadow":"False"}
# content.buttons_content: {"text": "[купить — 420 ₿]", "color": "black"}

# content.components.initial: 0

scoreboard objectives add settings.gust_emitter.spinner.buy dummy

scoreboard players set #value settings.gust_emitter.spinner.buy 0

execute store result score #max settings.gust_emitter.spinner.buy run data get entity @s data.buttons

# GET Y
function settings:gust_emitter/internal/content/math/get_y

# CONTENT
function settings:gust_emitter/parameters/spinner/buy/content with storage data:settings t