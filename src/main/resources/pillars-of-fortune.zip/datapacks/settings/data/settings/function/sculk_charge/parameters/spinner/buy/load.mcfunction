# namespace: sculk_charge
# name: buy
# type: spinner

# content.buttons_appearance: {"background":"-8403681", "shadow":"False"}
# content.buttons_content: {"text": "[купить — 379 ₿]", "color": "black"}

# content.components.initial: 0

scoreboard objectives add settings.sculk_charge.spinner.buy dummy

scoreboard players set #value settings.sculk_charge.spinner.buy 0

execute store result score #max settings.sculk_charge.spinner.buy run data get entity @s data.buttons

# GET Y
function settings:sculk_charge/internal/content/math/get_y

# CONTENT
function settings:sculk_charge/parameters/spinner/buy/content with storage data:settings t