$title @s title [{"text": "$(visible_name)", "color": "red"}]
title @s subtitle [{"text": "ивент над всеми игроками", "color": "white"}]

effect give @s strength 24 1 true