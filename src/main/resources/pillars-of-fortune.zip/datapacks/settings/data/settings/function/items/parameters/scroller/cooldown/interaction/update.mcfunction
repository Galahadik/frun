execute as @e[  tag = settings.items, tag = settings.items.scroller.cooldown.placeholder ] run data modify entity @s text set value [{"score": {"objective": "settings.items.scroller.cooldown", "name": "#value"}, "color": "#ababab"}, {"text": "с", "color": "#ababab"}]

execute as @e[  tag = settings.items, tag = settings.items.scroller.cooldown.buttons.left ] run data modify entity @s background set value -3727585
execute as @e[  tag = settings.items, tag = settings.items.scroller.cooldown.buttons.right ] run data modify entity @s background set value -8337633

execute if score #min settings.items.scroller.cooldown = #value settings.items.scroller.cooldown as @e[  tag = settings.items, tag = settings.items.scroller.cooldown.buttons.left ] run data modify entity @s background set value -5526613
execute if score #max settings.items.scroller.cooldown = #value settings.items.scroller.cooldown as @e[  tag = settings.items, tag = settings.items.scroller.cooldown.buttons.right ] run data modify entity @s background set value -5526613



execute store result storage settings:pillars t.items.cooldown int 1 run scoreboard players get #value settings.items.scroller.cooldown