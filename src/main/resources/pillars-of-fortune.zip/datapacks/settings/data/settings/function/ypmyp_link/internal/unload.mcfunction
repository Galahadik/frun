# ypmyp_link
kill @e[ tag = settings.ypmyp_link ]

scoreboard players reset * settings.ypmyp_link.spinner.button
scoreboard objectives remove settings.ypmyp_link.spinner.button