# namespace: totem_of_undying
# name: equip
# type: spinner

# content.buttons_appearance: {"background":"-5658199", "shadow":"False"}
# content.buttons_content: {"text": "[экипировать]", "color": "black"}

# content.components.initial: 0

scoreboard objectives add settings.totem_of_undying.spinner.equip dummy

scoreboard players set #value settings.totem_of_undying.spinner.equip 0

execute store result score #max settings.totem_of_undying.spinner.equip run data get entity @s data.buttons

# GET Y
function settings:totem_of_undying/internal/content/math/get_y

# CONTENT
function settings:totem_of_undying/parameters/spinner/equip/content with storage data:settings t