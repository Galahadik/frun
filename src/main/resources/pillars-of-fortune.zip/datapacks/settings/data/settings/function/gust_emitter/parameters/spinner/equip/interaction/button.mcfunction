scoreboard players add #value settings.gust_emitter.spinner.equip 1
execute if score #value settings.gust_emitter.spinner.equip >= #max settings.gust_emitter.spinner.equip run scoreboard players set #value settings.gust_emitter.spinner.equip 0

function settings:gust_emitter/parameters/spinner/equip/interaction/update/update_button

function settings:gust_emitter/parameters/spinner/equip/interaction/events

data remove entity @s interaction