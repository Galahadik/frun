# items
# scroller
# min_count

execute as @e[ tag = settings.items, tag = settings.items.scroller.min_count.buttons.left.interaction, nbt={interaction:{}}] run function settings:items/parameters/scroller/min_count/interaction/left_button/button

execute as @e[ tag = settings.items, tag = settings.items.scroller.min_count.buttons.right.interaction, nbt={interaction:{}}] run function settings:items/parameters/scroller/min_count/interaction/right_button/button