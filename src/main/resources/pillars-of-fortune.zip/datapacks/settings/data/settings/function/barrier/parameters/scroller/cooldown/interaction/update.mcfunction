execute as @e[  tag = settings.barrier, tag = settings.barrier.scroller.cooldown.placeholder ] run data modify entity @s text set value [{"score": {"objective": "settings.barrier.scroller.cooldown", "name": "#value"}, "color": "#ababab"}, {"text": "с", "color": "#ababab"}]

execute as @e[  tag = settings.barrier, tag = settings.barrier.scroller.cooldown.buttons.left ] run data modify entity @s background set value -3727585
execute as @e[  tag = settings.barrier, tag = settings.barrier.scroller.cooldown.buttons.right ] run data modify entity @s background set value -8337633

execute if score #min settings.barrier.scroller.cooldown = #value settings.barrier.scroller.cooldown as @e[  tag = settings.barrier, tag = settings.barrier.scroller.cooldown.buttons.left ] run data modify entity @s background set value -5526613
execute if score #max settings.barrier.scroller.cooldown = #value settings.barrier.scroller.cooldown as @e[  tag = settings.barrier, tag = settings.barrier.scroller.cooldown.buttons.right ] run data modify entity @s background set value -5526613



execute store result storage settings:pillars t.barrier.cooldown int 1 run scoreboard players get #value settings.barrier.scroller.cooldown