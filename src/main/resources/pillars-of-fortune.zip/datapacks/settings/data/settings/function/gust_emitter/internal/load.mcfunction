# namespace: gust_emitter

# REMOVE DATA
data modify storage data:settings t.parameters set value [{"name":"buy", "type":"spinner"},{"name":"equip", "type":"spinner"}]

# COORDINATES
function settings:gust_emitter/internal/content/math/coordinates

$data modify storage data:settings t.rot set value $(rot)


# HEADER and GET Y
function settings:gust_emitter/internal/content/math/get_y
function settings:gust_emitter/internal/content/header with storage data:settings t

# "load_parameters": 
function settings:gust_emitter/parameters/spinner/buy/load with storage data:settings t
function settings:gust_emitter/parameters/spinner/equip/load with storage data:settings t

# FOOTER and GET Y
function settings:gust_emitter/internal/content/math/get_y
function settings:gust_emitter/internal/content/footer with storage data:settings t

# REMOVE DATA
data remove storage data:settings t