# namespace: ypmyp_link
# name: button
# type: spinner

# content.buttons_appearance: {"background":"-667843", "shadow":"False"}
# content.buttons_content: {"text": "[вступить]", "color": "black"}

# content.components.initial: 0

scoreboard objectives add settings.ypmyp_link.spinner.button dummy

scoreboard players set #value settings.ypmyp_link.spinner.button 0

execute store result score #max settings.ypmyp_link.spinner.button run data get entity @s data.buttons

# GET Y
function settings:ypmyp_link/internal/content/math/get_y

# CONTENT
function settings:ypmyp_link/parameters/spinner/button/content with storage data:settings t