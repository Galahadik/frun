execute store result entity @s data.current_id int 1 run scoreboard players get #value settings.sculk_charge.spinner.buy

function settings:sculk_charge/parameters/spinner/buy/interaction/update/set_button with entity @s data

execute store result score #max settings.sculk_charge.spinner.buy run data get entity @s data.buttons