# namespace: modes
# name: events
# type: spinner

# content.buttons_appearance: {"background":"-3858657", "shadow":"False"},{"background":"-8403681", "shadow":"False"}
# content.buttons_content: {"text": "[выключено]", "color": "black"},{"text": "[включено]", "color": "black"}

# content.components.initial: 0

scoreboard objectives add settings.modes.spinner.events dummy

scoreboard players set #value settings.modes.spinner.events 0

execute store result score #max settings.modes.spinner.events run data get entity @s data.buttons

# GET Y
function settings:modes/internal/content/math/get_y

# CONTENT
function settings:modes/parameters/spinner/events/content with storage data:settings t