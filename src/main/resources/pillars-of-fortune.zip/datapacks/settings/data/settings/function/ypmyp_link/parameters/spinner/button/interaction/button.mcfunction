scoreboard players add #value settings.ypmyp_link.spinner.button 1
execute if score #value settings.ypmyp_link.spinner.button >= #max settings.ypmyp_link.spinner.button run scoreboard players set #value settings.ypmyp_link.spinner.button 0

function settings:ypmyp_link/parameters/spinner/button/interaction/update/update_button

function settings:ypmyp_link/parameters/spinner/button/interaction/events

data remove entity @s interaction