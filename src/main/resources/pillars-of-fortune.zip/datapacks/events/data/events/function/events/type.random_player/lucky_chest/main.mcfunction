$execute as @a run title @s title [{"text": "$(visible_name)", "color": "red"}]
title @a subtitle [{"text":"над игроком, "}, {"selector": "@s", }, {"text": ", произошёл ивент", "color": "white"}]

$scoreboard objectives add events.$(name) dummy

$function events:events/type.random_player/lucky_chest/functions/limit_coordinates $(data)