# namespace: large_smoke
# name: equip
# type: spinner

# content.buttons_appearance: {"background":"-5658199", "shadow":"False"}
# content.buttons_content: {"text": "[экипировать]", "color": "black"}

# content.components.initial: 0

scoreboard objectives add settings.large_smoke.spinner.equip dummy

scoreboard players set #value settings.large_smoke.spinner.equip 0

execute store result score #max settings.large_smoke.spinner.equip run data get entity @s data.buttons

# GET Y
function settings:large_smoke/internal/content/math/get_y

# CONTENT
function settings:large_smoke/parameters/spinner/equip/content with storage data:settings t