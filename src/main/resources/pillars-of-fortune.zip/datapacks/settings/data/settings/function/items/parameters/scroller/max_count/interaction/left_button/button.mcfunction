execute if score #min settings.items.scroller.max_count < #value settings.items.scroller.max_count run function settings:items/parameters/scroller/max_count/interaction/left_button/remove
execute if score #min settings.items.scroller.max_count >= #value settings.items.scroller.max_count run scoreboard players operation #value settings.items.scroller.max_count = #min settings.items.scroller.max_count

function settings:items/parameters/scroller/max_count/interaction/update

data remove entity @s interaction