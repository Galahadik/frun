# EVENTS INTERACTION

function settings:items/parameters/scroller/min_count/events/min_count with entity @s interaction