$scoreboard players reset #ticks events.$(name)

$scoreboard players set #z_x events.$(name) -47
$scoreboard players set #z_z events.$(name) 208

$scoreboard players set #x_x events.$(name) 38
$scoreboard players set #x_z events.$(name) 292

# ХРАНИЛИЩА
data modify storage data:events t.events.fire_rain set value {}
$data modify storage data:events t.events.fire_rain.name set value $(name)

$execute store result storage data:events t.events.fire_rain.z_x int 1 run scoreboard players get #z_x events.$(name)
$execute store result storage data:events t.events.fire_rain.z_z int 1 run scoreboard players get #z_z events.$(name)

$execute store result storage data:events t.events.fire_rain.x_x int 1 run scoreboard players get #x_x events.$(name)
$execute store result storage data:events t.events.fire_rain.x_z int 1 run scoreboard players get #x_z events.$(name)

function events:events/type.overworld/fire_rain/functions/random_coordinates with storage data:events t.events.fire_rain