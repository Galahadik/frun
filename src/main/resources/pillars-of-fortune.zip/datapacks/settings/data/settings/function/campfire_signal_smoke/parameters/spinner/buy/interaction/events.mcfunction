# EVENTS INTERACTION

function settings:campfire_signal_smoke/parameters/spinner/buy/events/buy with entity @s interaction