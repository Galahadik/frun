execute store result entity @s data.current_id int 1 run scoreboard players get #value settings.ypmyp_link.spinner.button

function settings:ypmyp_link/parameters/spinner/button/interaction/update/set_button with entity @s data

execute store result score #max settings.ypmyp_link.spinner.button run data get entity @s data.buttons