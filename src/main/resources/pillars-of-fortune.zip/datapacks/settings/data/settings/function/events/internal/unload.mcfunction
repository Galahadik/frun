# events
kill @e[ tag = settings.events ]

scoreboard players reset * settings.events.scroller.minutes
scoreboard objectives remove settings.events.scroller.minutes
scoreboard players reset * settings.events.scroller.seconds
scoreboard objectives remove settings.events.scroller.seconds