# events
# scroller
# minutes

execute as @e[ tag = settings.events, tag = settings.events.scroller.minutes.buttons.left.interaction, nbt={interaction:{}}] run function settings:events/parameters/scroller/minutes/interaction/left_button/button

execute as @e[ tag = settings.events, tag = settings.events.scroller.minutes.buttons.right.interaction, nbt={interaction:{}}] run function settings:events/parameters/scroller/minutes/interaction/right_button/button