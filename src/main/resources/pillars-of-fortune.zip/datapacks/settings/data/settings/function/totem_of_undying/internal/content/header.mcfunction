# CONTENT

# content.components.compound: [{"text": "ᴘʟᴀʏᴇʀ ᴋɪʟʟ", "color": "white"}]
# content.components.width: "                         "

# content.appearance.header.background: -15066852
# content.appearance.compound.background: 0
# content.appearance.compound.shadow: False

# REMOVE CURRENT Y
function settings:totem_of_undying/internal/content/math/remove_y

$summon text_display ^ ^$(y_current) ^ { \
    "Tags": [ "settings.totem_of_undying" ], \
    \
    Passengers: [ \
        { \
            "comment": "=== COMPOUND ===", \
            "id": "minecraft:text_display", \
            \
            "text": [{"text": "ᴘʟᴀʏᴇʀ ᴋɪʟʟ", "color": "white"}], \
            "background": 0, \
            "shadow": False, \
            "Tags": [ settings.totem_of_undying, "settings.totem_of_undying.header.compound" ], \
            "Rotation": [$(rot)f, 0f] \
        }, \
        { \
            "id": "minecraft:text_display", \
            \
            "text": { "text": "                         " }, \
            "background": -15066852, \
            "Tags": [ settings.totem_of_undying, "settings.totem_of_undying.header.background" ], \
            "Rotation": [$(rot)f, 0f] \
        } \
    ] \
}