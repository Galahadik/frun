# modes
# spinner
# events

execute as @e[ tag = settings.modes, tag = settings.modes.spinner.events.button.interaction, nbt={interaction:{}}] run function settings:modes/parameters/spinner/events/interaction/button