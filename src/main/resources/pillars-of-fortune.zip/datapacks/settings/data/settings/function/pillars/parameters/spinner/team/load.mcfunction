# namespace: pillars
# name: team
# type: spinner

# content.buttons_appearance: {"background":"-273091", "shadow":"False"},{"background":"-273091", "shadow":"False"}
# content.buttons_content: {"text": "[одиночные]", "color": "black"},{"text": "[командные]", "color": "black"}

# content.components.initial: 0

scoreboard objectives add settings.pillars.spinner.team dummy

scoreboard players set #value settings.pillars.spinner.team 0

execute store result score #max settings.pillars.spinner.team run data get entity @s data.buttons

# GET Y
function settings:pillars/internal/content/math/get_y

# CONTENT
function settings:pillars/parameters/spinner/team/content with storage data:settings t