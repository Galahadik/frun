scoreboard players add #value settings.pillars.spinner.team 1
execute if score #value settings.pillars.spinner.team >= #max settings.pillars.spinner.team run scoreboard players set #value settings.pillars.spinner.team 0

function settings:pillars/parameters/spinner/team/interaction/update/update_button

function settings:pillars/parameters/spinner/team/interaction/events

data remove entity @s interaction