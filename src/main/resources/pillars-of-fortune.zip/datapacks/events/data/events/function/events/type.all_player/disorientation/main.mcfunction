$title @s title [{"text": "$(visible_name)", "color": "red"}]
title @s subtitle [{"text": "ивент над всеми игроками", "color": "white"}]

effect give @s blindness 12 3 true
effect give @s darkness 12 3 true
effect give @s slowness 6 3 true