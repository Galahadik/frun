$data modify entity @s background set value $(background)
$data modify entity @s shadow set value $(shadow)