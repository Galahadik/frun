# CONTENT

# content.components.content.width: "                         "

# content.appearance.footer.background: -15066852

# FOOTER
$summon text_display ~ ~$(y_current) ~ { \
    "text": { "text": "                         " }, \
    "background": -15066852, \
    "Tags": [ settings.totem_of_undying, "settings.totem_of_undying.footer.background" ], \
    "Rotation": [$(rot)f, 0f] \
}