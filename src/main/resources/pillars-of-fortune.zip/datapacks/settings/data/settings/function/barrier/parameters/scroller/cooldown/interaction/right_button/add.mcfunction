scoreboard players operation #value settings.barrier.scroller.cooldown += #step settings.barrier.scroller.cooldown

function settings:barrier/parameters/scroller/cooldown/interaction/right_button/events