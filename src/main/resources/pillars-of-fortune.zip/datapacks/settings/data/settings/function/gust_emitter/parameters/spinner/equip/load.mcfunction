# namespace: gust_emitter
# name: equip
# type: spinner

# content.buttons_appearance: {"background":"-5658199", "shadow":"False"}
# content.buttons_content: {"text": "[экипировать]", "color": "black"}

# content.components.initial: 0

scoreboard objectives add settings.gust_emitter.spinner.equip dummy

scoreboard players set #value settings.gust_emitter.spinner.equip 0

execute store result score #max settings.gust_emitter.spinner.equip run data get entity @s data.buttons

# GET Y
function settings:gust_emitter/internal/content/math/get_y

# CONTENT
function settings:gust_emitter/parameters/spinner/equip/content with storage data:settings t