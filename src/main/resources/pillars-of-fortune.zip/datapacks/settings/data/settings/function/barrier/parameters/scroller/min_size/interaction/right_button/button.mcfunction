execute if score #max settings.barrier.scroller.min_size > #value settings.barrier.scroller.min_size run function settings:barrier/parameters/scroller/min_size/interaction/right_button/add
execute if score #max settings.barrier.scroller.min_size <= #value settings.barrier.scroller.min_size run scoreboard players operation #value settings.barrier.scroller.min_size = #max settings.barrier.scroller.min_size

function settings:barrier/parameters/scroller/min_size/interaction/update

data remove entity @s interaction