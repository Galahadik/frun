scoreboard players operation #value settings.items.scroller.max_count -= #step settings.items.scroller.max_count

function settings:items/parameters/scroller/max_count/interaction/left_button/events