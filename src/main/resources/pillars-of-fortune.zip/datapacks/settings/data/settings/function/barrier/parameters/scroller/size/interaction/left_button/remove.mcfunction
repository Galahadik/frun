scoreboard players operation #value settings.barrier.scroller.size -= #step settings.barrier.scroller.size

function settings:barrier/parameters/scroller/size/interaction/left_button/events