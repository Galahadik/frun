execute store result entity @s data.current_id int 1 run scoreboard players get #value settings.gust_emitter.spinner.equip

function settings:gust_emitter/parameters/spinner/equip/interaction/update/set_button with entity @s data

execute store result score #max settings.gust_emitter.spinner.equip run data get entity @s data.buttons