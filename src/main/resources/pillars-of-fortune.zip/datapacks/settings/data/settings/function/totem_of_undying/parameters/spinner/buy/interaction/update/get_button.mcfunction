execute store result entity @s data.current_id int 1 run scoreboard players get #value settings.totem_of_undying.spinner.buy

function settings:totem_of_undying/parameters/spinner/buy/interaction/update/set_button with entity @s data

execute store result score #max settings.totem_of_undying.spinner.buy run data get entity @s data.buttons