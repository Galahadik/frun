execute if score #max settings.items.scroller.cooldown > #value settings.items.scroller.cooldown run function settings:items/parameters/scroller/cooldown/interaction/right_button/add
execute if score #max settings.items.scroller.cooldown <= #value settings.items.scroller.cooldown run scoreboard players operation #value settings.items.scroller.cooldown = #max settings.items.scroller.cooldown

function settings:items/parameters/scroller/cooldown/interaction/update

data remove entity @s interaction