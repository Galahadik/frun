execute if score #min settings.barrier.scroller.size < #value settings.barrier.scroller.size run function settings:barrier/parameters/scroller/size/interaction/left_button/remove
execute if score #min settings.barrier.scroller.size >= #value settings.barrier.scroller.size run scoreboard players operation #value settings.barrier.scroller.size = #min settings.barrier.scroller.size

function settings:barrier/parameters/scroller/size/interaction/update

data remove entity @s interaction