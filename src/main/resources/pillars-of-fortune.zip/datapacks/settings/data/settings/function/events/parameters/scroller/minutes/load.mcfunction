# namespace: events
# name: minutes
# type: scroller

# content.components.max: 60
# content.components.min: 0
# content.components.step: 1
# content.components.initial: 0

scoreboard objectives add settings.events.scroller.minutes dummy

scoreboard players set #max settings.events.scroller.minutes 60
scoreboard players set #min settings.events.scroller.minutes 0
scoreboard players set #step settings.events.scroller.minutes 1
scoreboard players set #value settings.events.scroller.minutes 0

# GET Y
function settings:events/internal/content/math/get_y

# CONTENT
function settings:events/parameters/scroller/minutes/content with storage data:settings t

# UPDATE
function settings:events/parameters/scroller/minutes/interaction/update