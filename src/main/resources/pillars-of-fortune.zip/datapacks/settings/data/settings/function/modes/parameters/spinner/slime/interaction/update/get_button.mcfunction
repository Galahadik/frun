execute store result entity @s data.current_id int 1 run scoreboard players get #value settings.modes.spinner.slime

function settings:modes/parameters/spinner/slime/interaction/update/set_button with entity @s data

execute store result score #max settings.modes.spinner.slime run data get entity @s data.buttons