scoreboard players operation #value settings.barrier.scroller.narrowing += #step settings.barrier.scroller.narrowing

function settings:barrier/parameters/scroller/narrowing/interaction/right_button/events