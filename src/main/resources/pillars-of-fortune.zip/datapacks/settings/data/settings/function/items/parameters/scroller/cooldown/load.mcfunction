# namespace: items
# name: cooldown
# type: scroller

# content.components.max: 999
# content.components.min: 1
# content.components.step: 1
# content.components.initial: 10

scoreboard objectives add settings.items.scroller.cooldown dummy

scoreboard players set #max settings.items.scroller.cooldown 999
scoreboard players set #min settings.items.scroller.cooldown 1
scoreboard players set #step settings.items.scroller.cooldown 1
scoreboard players set #value settings.items.scroller.cooldown 10

# GET Y
function settings:items/internal/content/math/get_y

# CONTENT
function settings:items/parameters/scroller/cooldown/content with storage data:settings t

# UPDATE
function settings:items/parameters/scroller/cooldown/interaction/update