# "tick_parameters": 
function settings:ominous_spawning/parameters/spinner/buy/tick
function settings:ominous_spawning/parameters/spinner/equip/tick