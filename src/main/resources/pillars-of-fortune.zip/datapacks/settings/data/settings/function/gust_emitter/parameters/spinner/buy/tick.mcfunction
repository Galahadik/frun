# gust_emitter
# spinner
# buy

execute as @e[ tag = settings.gust_emitter, tag = settings.gust_emitter.spinner.buy.button.interaction, nbt={interaction:{}}] run function settings:gust_emitter/parameters/spinner/buy/interaction/button