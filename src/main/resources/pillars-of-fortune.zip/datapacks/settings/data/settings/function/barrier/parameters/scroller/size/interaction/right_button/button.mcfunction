execute if score #max settings.barrier.scroller.size > #value settings.barrier.scroller.size run function settings:barrier/parameters/scroller/size/interaction/right_button/add
execute if score #max settings.barrier.scroller.size <= #value settings.barrier.scroller.size run scoreboard players operation #value settings.barrier.scroller.size = #max settings.barrier.scroller.size

function settings:barrier/parameters/scroller/size/interaction/update

data remove entity @s interaction