execute as @e[  tag = settings.events, tag = settings.events.scroller.minutes.placeholder ] run data modify entity @s text set value [{"score": {"objective": "settings.events.scroller.minutes", "name": "#value"}, "color": "#ababab"}, {"text": "м", "color": "#ababab"}]

execute as @e[  tag = settings.events, tag = settings.events.scroller.minutes.buttons.left ] run data modify entity @s background set value -3727585
execute as @e[  tag = settings.events, tag = settings.events.scroller.minutes.buttons.right ] run data modify entity @s background set value -8337633

execute if score #min settings.events.scroller.minutes = #value settings.events.scroller.minutes as @e[  tag = settings.events, tag = settings.events.scroller.minutes.buttons.left ] run data modify entity @s background set value -5526613
execute if score #max settings.events.scroller.minutes = #value settings.events.scroller.minutes as @e[  tag = settings.events, tag = settings.events.scroller.minutes.buttons.right ] run data modify entity @s background set value -5526613



execute store result storage settings:pillars t.events.cooldown_minutes int 1 run scoreboard players get #value settings.events.scroller.minutes