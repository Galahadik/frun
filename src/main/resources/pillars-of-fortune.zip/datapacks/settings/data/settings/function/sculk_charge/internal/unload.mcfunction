# sculk_charge
kill @e[ tag = settings.sculk_charge ]

scoreboard players reset * settings.sculk_charge.spinner.buy
scoreboard objectives remove settings.sculk_charge.spinner.buy
scoreboard players reset * settings.sculk_charge.spinner.equip
scoreboard objectives remove settings.sculk_charge.spinner.equip