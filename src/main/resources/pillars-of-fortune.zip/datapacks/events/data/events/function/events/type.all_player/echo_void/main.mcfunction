$title @s title [{"text": "$(visible_name)", "color": "red"}]
title @s subtitle [{"text": "ивент над всеми игроками", "color": "white"}]

execute at @s run playsound minecraft:ambient.cave master @s ~ ~ ~ 1 1