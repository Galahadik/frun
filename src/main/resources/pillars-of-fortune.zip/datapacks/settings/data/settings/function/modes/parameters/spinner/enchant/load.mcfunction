# namespace: modes
# name: enchant
# type: spinner

# content.buttons_appearance: {"background":"-3858657", "shadow":"False"},{"background":"-8403681", "shadow":"False"}
# content.buttons_content: {"text": "[выключено]", "color": "black"},{"text": "[включено]", "color": "black"}

# content.components.initial: 0

scoreboard objectives add settings.modes.spinner.enchant dummy

scoreboard players set #value settings.modes.spinner.enchant 0

execute store result score #max settings.modes.spinner.enchant run data get entity @s data.buttons

# GET Y
function settings:modes/internal/content/math/get_y

# CONTENT
function settings:modes/parameters/spinner/enchant/content with storage data:settings t