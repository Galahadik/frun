$scoreboard players reset #ticks events.$(name)

$scoreboard players set #x events.$(name) 5
$scoreboard players set #z events.$(name) -5

$scoreboard players set #y.min events.$(name) -5
$scoreboard players set #y.max events.$(name) 5

# ХРАНИЛИЩА
data modify storage data:events t.events.lucky_chest set value {}
$data modify storage data:events t.events.lucky_chest.name set value $(name)

$execute store result storage data:events t.events.lucky_chest.x int 1 run scoreboard players get #x events.$(name)
$execute store result storage data:events t.events.lucky_chest.z int 1 run scoreboard players get #z events.$(name)

$execute store result storage data:events t.events.lucky_chest.y_min int 1 run scoreboard players get #y.min events.$(name)
$execute store result storage data:events t.events.lucky_chest.y_max int 1 run scoreboard players get #y.max events.$(name)

function events:events/type.random_player/lucky_chest/functions/random_coordinates with storage data:events t.events.lucky_chest