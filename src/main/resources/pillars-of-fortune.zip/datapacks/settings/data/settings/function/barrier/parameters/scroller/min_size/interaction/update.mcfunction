execute as @e[  tag = settings.barrier, tag = settings.barrier.scroller.min_size.placeholder ] run data modify entity @s text set value [{"score": {"objective": "settings.barrier.scroller.min_size", "name": "#value"}, "color": "#ababab"}, {"text": "б", "color": "#ababab"}]

execute as @e[  tag = settings.barrier, tag = settings.barrier.scroller.min_size.buttons.left ] run data modify entity @s background set value -3727585
execute as @e[  tag = settings.barrier, tag = settings.barrier.scroller.min_size.buttons.right ] run data modify entity @s background set value -8337633

execute if score #min settings.barrier.scroller.min_size = #value settings.barrier.scroller.min_size as @e[  tag = settings.barrier, tag = settings.barrier.scroller.min_size.buttons.left ] run data modify entity @s background set value -5526613
execute if score #max settings.barrier.scroller.min_size = #value settings.barrier.scroller.min_size as @e[  tag = settings.barrier, tag = settings.barrier.scroller.min_size.buttons.right ] run data modify entity @s background set value -5526613



execute store result storage settings:pillars t.barrier.min_size int 1 run scoreboard players get #value settings.barrier.scroller.min_size