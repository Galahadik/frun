# namespace: modes
# name: events
# type: spinner

# content.appearance.content.background: -15066852

# content.appearance.compound.background: 0
# content.appearance.compound.shadow: False

# content.components.compound: [{"text": "ивенты", "color": "white"}]
# content.components.initial: 0

# content.components.content.width:                          

# REMOVE CURRENT Y
function settings:modes/internal/content/math/remove_y

$summon text_display ^ ^$(y_current) ^ { \
    "Tags": [ "settings.modes" ], \
    \
    Passengers: [ \
        { \
            "comment": "=== COMPOUND ===", \
            "id": "minecraft:text_display", \
            \
            "text": [{"text": "ивенты", "color": "white"}], \
            "background": 0, \
            "shadow": False, \
            "Tags": [ "settings.modes", "settings.modes.spinner.events.compound" ], \
            "transformation": { \
                "translation": [0, 0.4, 0.01], \
                "scale": [1, 1, 1], \
                "left_rotation": [0, 0, 0, 1], \
                "right_rotation": [0, 0, 0, 1] \
            }, \
            "Rotation": [$(rot)f, 0f] \
        }, \
        { \
            "comment": "=== BUTTON ===", \
            "id": "minecraft:text_display", \
            \
            "text": {"text": ""}, \
            "background": 0, \
            "shadow": false, \
            "Tags": [ "settings.modes", "settings.modes.spinner.events.button" ], \
            "transformation": { \
                "translation": [0, 0.1, 0.01], \
                "scale": [1, 1, 1], \
                "left_rotation": [0, 0, 0, 1], \
                "right_rotation": [0, 0, 0, 1] \
            }, \
            "data": { \
                "buttons": [{"text": "[выключено]", "color": "black"},{"text": "[включено]", "color": "black"}], \
                "appearance": [{"background":"-3858657", "shadow":"False"},{"background":"-8403681", "shadow":"False"}], \
                "current_id": 0, \
                "current_button": {}, \
                "current_appearance": {} \
            }, \
            "Rotation": [$(rot)f, 0f] \
        }, \
        { \
            "comment": "=== BACKGROUND ===", \
            "id": "minecraft:text_display", \
            \
            "text": { "text": "                         " }, \
            "background": -15066852, \
            "Tags": [ "settings.modes", "settings.modes.spinner.events.background" ], \
            "transformation": { \
                "translation": [0, 0, 0], \
                "scale": [1, 3, 1], \
                "left_rotation": [0, 0, 0, 1], \
                "right_rotation": [0, 0, 0, 1] \
            }, \
            "Rotation": [$(rot)f, 0f] \
        } \
    ] \
}

$summon interaction ^ ^$(y_current) ^ { \
    "Tags": [ "settings.modes", "settings.modes.spinner.events.button.interaction" ], \
    "width": 1f, \
    "height": 0.25f \
}
execute as @e[ tag = settings.modes, tag = settings.modes.spinner.events.button.interaction] at @s run tp @s ^ ^0.1 ^

function settings:modes/parameters/spinner/events/interaction/update/update_button