# ypmyp_link
# spinner
# button

execute as @e[ tag = settings.ypmyp_link, tag = settings.ypmyp_link.spinner.button.button.interaction, nbt={interaction:{}}] run function settings:ypmyp_link/parameters/spinner/button/interaction/button