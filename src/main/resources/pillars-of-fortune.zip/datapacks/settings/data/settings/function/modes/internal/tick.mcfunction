# "tick_parameters": 
function settings:modes/parameters/spinner/events/tick
function settings:modes/parameters/spinner/enchant/tick
function settings:modes/parameters/spinner/slime/tick