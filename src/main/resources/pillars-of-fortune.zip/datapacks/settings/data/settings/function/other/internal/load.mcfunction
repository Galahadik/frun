# namespace: other

# REMOVE DATA
data modify storage data:settings t.parameters set value [{"name":"scoreboard", "type":"spinner"},{"name":"operators", "type":"spinner"},{"name":"cooperators", "type":"spinner"}]

# COORDINATES
function settings:other/internal/content/math/coordinates

$data modify storage data:settings t.rot set value $(rot)


# HEADER and GET Y
function settings:other/internal/content/math/get_y
function settings:other/internal/content/header with storage data:settings t

# "load_parameters": 
function settings:other/parameters/spinner/scoreboard/load with storage data:settings t
function settings:other/parameters/spinner/operators/load with storage data:settings t
function settings:other/parameters/spinner/cooperators/load with storage data:settings t

# FOOTER and GET Y
function settings:other/internal/content/math/get_y
function settings:other/internal/content/footer with storage data:settings t

# REMOVE DATA
data remove storage data:settings t