execute store result entity @s data.current_id int 1 run scoreboard players get #value settings.modes.spinner.events

function settings:modes/parameters/spinner/events/interaction/update/set_button with entity @s data

execute store result score #max settings.modes.spinner.events run data get entity @s data.buttons