# items
kill @e[ tag = settings.items ]

scoreboard players reset * settings.items.scroller.cooldown
scoreboard objectives remove settings.items.scroller.cooldown
scoreboard players reset * settings.items.scroller.min_count
scoreboard objectives remove settings.items.scroller.min_count
scoreboard players reset * settings.items.scroller.max_count
scoreboard objectives remove settings.items.scroller.max_count