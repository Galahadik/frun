# effect_kill
kill @e[ tag = settings.effect_kill ]

scoreboard players reset * settings.effect_kill.spinner.unequip
scoreboard objectives remove settings.effect_kill.spinner.unequip