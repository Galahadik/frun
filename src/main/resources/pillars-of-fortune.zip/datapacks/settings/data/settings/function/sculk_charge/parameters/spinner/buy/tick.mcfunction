# sculk_charge
# spinner
# buy

execute as @e[ tag = settings.sculk_charge, tag = settings.sculk_charge.spinner.buy.button.interaction, nbt={interaction:{}}] run function settings:sculk_charge/parameters/spinner/buy/interaction/button