$execute as @a run title @s title [{"text": "$(visible_name)", "color": "red"}]
title @a subtitle [{"text":"над игроком, "}, {"selector": "@s", }, {"text": ", произошёл ивент", "color": "white"}]

loot give @s loot pillars:item