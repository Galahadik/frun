# EVENTS INTERACTION

function settings:large_smoke/parameters/spinner/equip/events/equip with entity @s interaction