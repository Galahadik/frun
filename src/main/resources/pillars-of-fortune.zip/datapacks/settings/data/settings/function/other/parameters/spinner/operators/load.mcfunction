# namespace: other
# name: operators
# type: spinner

# content.buttons_appearance: {"background":"-8403681", "shadow":"False"},{"background":"-3858657", "shadow":"False"}
# content.buttons_content: {"text": "[включено]", "color": "black"},{"text": "[выключено]", "color": "black"}

# content.components.initial: 0

scoreboard objectives add settings.other.spinner.operators dummy

scoreboard players set #value settings.other.spinner.operators 0

execute store result score #max settings.other.spinner.operators run data get entity @s data.buttons

# GET Y
function settings:other/internal/content/math/get_y

# CONTENT
function settings:other/parameters/spinner/operators/content with storage data:settings t