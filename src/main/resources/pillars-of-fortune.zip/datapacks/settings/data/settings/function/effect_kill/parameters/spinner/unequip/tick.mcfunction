# effect_kill
# spinner
# unequip

execute as @e[ tag = settings.effect_kill, tag = settings.effect_kill.spinner.unequip.button.interaction, nbt={interaction:{}}] run function settings:effect_kill/parameters/spinner/unequip/interaction/button