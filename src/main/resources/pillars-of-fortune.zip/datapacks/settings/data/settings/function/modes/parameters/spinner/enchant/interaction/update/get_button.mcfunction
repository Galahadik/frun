execute store result entity @s data.current_id int 1 run scoreboard players get #value settings.modes.spinner.enchant

function settings:modes/parameters/spinner/enchant/interaction/update/set_button with entity @s data

execute store result score #max settings.modes.spinner.enchant run data get entity @s data.buttons