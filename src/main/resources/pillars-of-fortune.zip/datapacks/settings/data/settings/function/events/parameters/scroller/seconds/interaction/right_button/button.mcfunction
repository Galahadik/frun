execute if score #max settings.events.scroller.seconds > #value settings.events.scroller.seconds run function settings:events/parameters/scroller/seconds/interaction/right_button/add
execute if score #max settings.events.scroller.seconds <= #value settings.events.scroller.seconds run scoreboard players operation #value settings.events.scroller.seconds = #max settings.events.scroller.seconds

function settings:events/parameters/scroller/seconds/interaction/update

data remove entity @s interaction