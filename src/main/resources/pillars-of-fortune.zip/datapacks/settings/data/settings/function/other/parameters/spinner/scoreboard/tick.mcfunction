# other
# spinner
# scoreboard

execute as @e[ tag = settings.other, tag = settings.other.spinner.scoreboard.button.interaction, nbt={interaction:{}}] run function settings:other/parameters/spinner/scoreboard/interaction/button