# "tick_parameters": 
function settings:ypmyp_link/parameters/spinner/button/tick